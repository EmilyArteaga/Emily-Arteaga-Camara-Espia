
package com.jwork.arteaga;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.Surface;

import com.jwork.arteaga.Capa_Negocio.Configuracion_Utilidad;
import com.jwork.arteaga.Capa_Negocio.ManejoColisiones;
import com.jwork.arteaga.Capa_Datos.UtilidadInicio;
import com.jwork.arteaga.Capa_Datos.Utilidades;

import java.lang.Thread.UncaughtExceptionHandler;

public class ActividadCamaraEspia extends FragmentActivity {

    public static final String[] ACTION_AJUSTES = new String[]{
            "AJUSTES_INICIAR_APP", "AJUSTE_UNICA_IMAGEN", "AJUSTE_AUTO_MODO", "AJUSTE_CARA_MODO", "AJUSTE_VIDEO_MODO"};

    private UtilidadInicio iniciar;
    private Main_Fragmentos fragmento;
    private UncaughtExceptionHandler defaultUEH;
    private ManejoColisiones manejoColisiones;
    private int defaultOrientacion;

    public ActividadCamaraEspia() {
//		Fabrica.resetear();
        iniciar = UtilidadInicio.getInstancia();
        iniciar.v(this, "constructor()");
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int valor = 0;
        try {
            valor = this.getPackageManager().getPackageInfo(this.getPackageName(), 0).versionCode;
        } catch (NameNotFoundException e) {
        }
        iniciar.v(this, "enCreacion(): " + this.getString(R.string.app_versionName) + "(" + valor + ")");
        Utilidades.setContextoGlobal(this);

        defaultUEH = Thread.getDefaultUncaughtExceptionHandler();
        manejoColisiones = ManejoColisiones.getInstancia(this, defaultUEH);
        Thread.setDefaultUncaughtExceptionHandler(manejoColisiones);
        setContentView(R.layout.activity_main);
        fragmento = (Main_Fragmentos) getSupportFragmentManager().findFragmentById(R.id.fragmentMain);

        getDefaultOrientacion();
        String action = getIntent().getAction();
        iniciar.d(this, "accion:" + action);
        if (action == null || action.equals("android.intent.action.MAIN") || action.equals(ACTION_AJUSTES[0])) {
            fragmento.setVisible();
        } else {
            for (int i = 1; i < ACTION_AJUSTES.length; i++) {
                if (action.equals(ACTION_AJUSTES[i])) {
                    if (Configuracion_Utilidad.getInstancia(this).getDeshabilitarSevicioBackground()) {
                        fragmento.setVisible();
                    } else {
                        fragmento.setVisibleForWidget();
                    }
                    fragmento.callWidgetAction(i);
                    return;
                }
            }
            fragmento.setVisible();
        }
    }


    private void getDefaultOrientacion() {
        int rotacion = getWindowManager().getDefaultDisplay().getRotation();
        DisplayMetrics metricas = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metricas);
        iniciar.v(this, "Pixeles de Visualizacion: " + metricas.widthPixels + "x" + metricas.heightPixels + "|Rotacion:" + rotacion);
        if (
                ((rotacion == Surface.ROTATION_0 || rotacion == Surface.ROTATION_180) && metricas.widthPixels > metricas.heightPixels)
                        || ((rotacion == Surface.ROTATION_90 || rotacion == Surface.ROTATION_270) && metricas.widthPixels < metricas.heightPixels)
                ) {
            rotacion += 1;
            if (rotacion > 3) {
                rotacion = 0;
            }
        }
        switch (rotacion) {
            case Surface.ROTATION_0:
                defaultOrientacion = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
                break;
            case Surface.ROTATION_90:
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.FROYO) {
                    defaultOrientacion = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
                } else {
                    defaultOrientacion = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
                    setRequestedOrientation(defaultOrientacion);
                }
                break;
            case Surface.ROTATION_180:
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.FROYO) {
                    defaultOrientacion = ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT;
                } else {
                    defaultOrientacion = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
                    setRequestedOrientation(defaultOrientacion);
                }
                break;
            case Surface.ROTATION_270:
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.FROYO) {
                    defaultOrientacion = ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE;
                } else {
                    defaultOrientacion = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
                    setRequestedOrientation(defaultOrientacion);
                }
                break;
        }
    }

    @SuppressLint("NuevaAppi")
    @Override
    protected void onResume() {
        iniciar.v(this, "enResumen()");
        super.onResume();
    }

    @Override
    protected void onPause() {
        iniciar.v(this, "enPausa()");
        super.onPause();
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        if (defaultUEH != null) {
            Thread.setDefaultUncaughtExceptionHandler(defaultUEH);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration nuevaConfiguracion) {
        super.onConfigurationChanged(nuevaConfiguracion);
        iniciar.d(this, "enCambioConfiguracion");
        setRequestedOrientation(defaultOrientacion);
    }

    @Override
    public boolean onKeyDown(int codigoLlave, KeyEvent evento) {
        iniciar.v(this, "onKeyDown(keycode:" + codigoLlave + ")");
        if (fragmento.onKeyDown(codigoLlave, evento)) {
            return true;
        }
        return super.onKeyDown(codigoLlave, evento);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent dato) {
        iniciar.v(this, "onActivityResult(requestCode:" + requestCode + "|resultCode:" + resultCode + ")");
    }

}
