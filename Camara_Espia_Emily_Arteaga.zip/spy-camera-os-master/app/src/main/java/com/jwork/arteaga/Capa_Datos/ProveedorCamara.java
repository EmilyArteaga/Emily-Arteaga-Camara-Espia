
package com.jwork.arteaga.Capa_Datos;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import com.jwork.arteaga.ActividadCamaraEspia;
import com.jwork.arteaga.Capa_Negocio.Configuracion_Utilidad;
import com.jwork.arteaga.R;

import java.util.Arrays;

public class ProveedorCamara extends AppWidgetProvider {

    private UtilidadInicio inicio = UtilidadInicio.getInstancia();

    public static void updateAppWidget(Context context, AppWidgetManager appWidgetManager,
                                       int appWidgetId) {
        UtilidadInicio log = UtilidadInicio.getInstancia();
        log.v(ProveedorCamara.class, "actualizarApp(id:" + appWidgetId + ")");

        new ProveedorCamara().onUpdate(context, appWidgetManager, new int[]{appWidgetId});
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        inicio.v(this, "Permitido");
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        inicio.v(this, "NoPermitido");
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        super.onDeleted(context, appWidgetIds);
        inicio.v(this, "Eliminando:" + Arrays.toString(appWidgetIds));
        for (int id : appWidgetIds) {
            Configuracion_Utilidad.getInstancia(context).eleminarConfiguracionAjuste(id);
        }
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager,
                         int[] appWidgetIds) {
        super.onUpdate(context, appWidgetManager, appWidgetIds);
        inicio.v(this, "Subiendo:" + Arrays.toString(appWidgetIds));
        Configuracion_Utilidad configuracion = Configuracion_Utilidad.getInstancia(context);
        for (int id : appWidgetIds) {
            int accion = configuracion.getAccionConfiguracionAjuste(id);
            if (accion == -1) {
                accion = 0;
            }
            Intent intento = new Intent(context, ActividadCamaraEspia.class);
            intento.setAction(ActividadCamaraEspia.ACTION_AJUSTES[accion]);
            intento.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, appWidgetIds);
            PendingIntent pedirIntento = PendingIntent.getActivity(context, 0, intento, 0);

            RemoteViews vistasRemotas = new RemoteViews(context.getPackageName(),
                    R.layout.widget_camera);
            vistasRemotas.setTextViewText(R.id.widgetText, configuracion.getConfiguracionTextoAjuste(id));
            vistasRemotas.setOnClickPendingIntent(R.id.widgetLayout, pedirIntento);
            appWidgetManager.updateAppWidget(id, vistasRemotas);
        }
    }

    @Override
    public void onReceive(Context contexto, Intent intento) {
        super.onReceive(contexto, intento);
        int id = intento.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1);
        inicio.v(this, "onReceive:" + id);
        if (id != -1) {
            onUpdate(contexto, AppWidgetManager.getInstance(contexto), new int[]{id});
        } else {
            ComponentName thisWidget = new ComponentName(contexto, ProveedorCamara.class);
            int[] ids = AppWidgetManager.getInstance(contexto).getAppWidgetIds(thisWidget);
            onUpdate(contexto, AppWidgetManager.getInstance(contexto), ids);
        }
    }

}
