
package com.jwork.arteaga.Capa_Datos;

import android.content.Context;
import android.util.Log;

import com.jwork.arteaga.Capa_Negocio.Configuracion_Utilidad;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class UtilidadInicio {

    private static final String SEPARADOR = "||";
    private static UtilidadInicio instancia;
    private java.text.DateFormat formatofecha;
    private boolean ingresar = false;
    private BufferedWriter buffescr;

    private UtilidadInicio() {
    }

    public synchronized static UtilidadInicio getInstancia() {
        if (instancia == null) {
            instancia = new UtilidadInicio();
        }
        return instancia;
    }

    public void PermitirIngreso(Context context) {
        formatofecha = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Configuracion_Utilidad config = Configuracion_Utilidad.getInstancia(context);
        File file = new File(config.getGuardarDireccionPrimaria() + File.separator + "ingresar.txt");
        if (file.exists() && file.isFile() && file.length() > 102400) {
            file.delete();
        }
        try {
            file.createNewFile();
            buffescr = new BufferedWriter(new FileWriter(file, true));
            this.ingresar = true;
        } catch (IOException e) {
            e(this, e);
        }
    }

    public void DeshabilitarIngreso() {
        ingresar = false;
        if (buffescr != null) {
            try {
                buffescr.flush();
            } catch (IOException e) {
            }
            try {
                buffescr.close();
            } catch (IOException e) {
            }
            buffescr = null;
        }
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        if (buffescr != null) {
            try {
                buffescr.close();
            } catch (Exception e) {
            }
        }
    }

    public void v(Object obj, String message) {
        if (ingresar) {
            Log.v(convetir(obj), message);
            try {
                buffescr.write(formatofecha.format(new Date()) + SEPARADOR + "[V]" + SEPARADOR + convetir(obj) + SEPARADOR + message + "\n");
                buffescr.flush();
            } catch (IOException e) {
            }
        }
    }

    private String convetir(Object obj) {
        if (obj instanceof String) {
            return "c:" + obj.toString();
        }
        return "c:" + obj.getClass().getSimpleName();
    }

    public void v(Class<?> cls, String message) {
        Log.v("c:" + cls.getSimpleName(), message);
        if (ingresar) {
            try {
                buffescr.write(formatofecha.format(new Date()) + SEPARADOR + "[V]" + SEPARADOR + "c:" + cls.getSimpleName() + SEPARADOR + message + "\n");
                buffescr.flush();
            } catch (IOException e) {
            }
        }
    }

    public void d(Object obj, String message) {
        if (ingresar) {
            Log.d(convetir(obj), message);
            try {
                buffescr.write(formatofecha.format(new Date()) + SEPARADOR + "[D]" + SEPARADOR + convetir(obj) + SEPARADOR + message + "\n");
                buffescr.flush();
            } catch (IOException e) {
            }
        }
    }

    public void i(Object obj, String message) {
        if (ingresar) {
            Log.i(convetir(obj), message);
            try {
                buffescr.write(formatofecha.format(new Date()) + SEPARADOR + "[I]" + SEPARADOR + convetir(obj) + SEPARADOR + message + "\n");
                buffescr.flush();
            } catch (IOException e) {
            }
        }
    }

    public void w(Object obj, String message) {
        if (ingresar) {
            Log.w(convetir(obj), message);
            try {
                buffescr.write(formatofecha.format(new Date()) + SEPARADOR + "[W]" + SEPARADOR + convetir(obj) + SEPARADOR + message + "\n");
                buffescr.flush();
            } catch (IOException e) {
            }
        }
    }

    public void e(Object obj, String message) {
        Log.e(convetir(obj), message);
        if (ingresar) {
            try {
                buffescr.write(formatofecha.format(new Date()) + SEPARADOR + "[E]" + SEPARADOR + convetir(obj) + SEPARADOR + message + "\n");
                buffescr.flush();
            } catch (IOException e) {
            }
        }
    }

    public void w(Object obj, Throwable e) {
        if (ingresar) {
            Log.e(convetir(obj), e.getClass().getName(), e);
            try {
                buffescr.write(formatofecha.format(new Date()) + SEPARADOR + "[W]" + SEPARADOR + convetir(obj) + SEPARADOR + e + "\n");
                StackTraceElement[] arr = e.getStackTrace();
                for (int i = 0; i < arr.length; i++) {
                    buffescr.write("    " + arr[i].toString() + "\n");
                }
                Throwable cause = e.getCause();
                if (cause != null) {
                    buffescr.write("Cause: " + cause.toString() + "\n");
                    arr = cause.getStackTrace();
                    for (int i = 0; i < arr.length; i++) {
                        buffescr.write("    " + arr[i].toString() + "\n");
                    }
                }
                buffescr.flush();
            } catch (IOException e2) {
            }
        }
    }

    public void e(Object obj, Throwable e) {
        if (ingresar) {
            Log.e(convetir(obj), e.getClass().getName(), e);
            try {
                buffescr.write(formatofecha.format(new Date()) + SEPARADOR + "[E]" + SEPARADOR + convetir(obj) + SEPARADOR + e + "\n");
                StackTraceElement[] arr = e.getStackTrace();
                for (int i = 0; i < arr.length; i++) {
                    buffescr.write("    " + arr[i].toString() + "\n");
                }
                Throwable cause = e.getCause();
                if (cause != null) {
                    buffescr.write("Cause: " + cause.toString() + "\n");
                    arr = cause.getStackTrace();
                    for (int i = 0; i < arr.length; i++) {
                        buffescr.write("    " + arr[i].toString() + "\n");
                    }
                }
                buffescr.flush();
            } catch (IOException e2) {
            }
        }
    }

    public void renombrarErrores() {
        String guardandoDireccion = Configuracion_Utilidad.getInstancia(null).getGuardarDireccionPrimaria();
        File file = new File(guardandoDireccion + File.separator + "ingresar.txt");
        File fileTarget = new File(guardandoDireccion + File.separator + "loggingError.txt");
        InputStream dentro = null;
        OutputStream fuera = null;
        try {
            dentro = new FileInputStream(file);
            fuera = new FileOutputStream(fileTarget);
            byte[] buf = new byte[1024];
            int len;
            while ((len = dentro.read(buf)) > 0) {
                fuera.write(buf, 0, len);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                dentro.close();
            } catch (Exception e) {
            }
            try {
                fuera.close();
            } catch (Exception e) {
            }
        }
    }

    public void eliminarRegistroErrores() {
        String savingPath = Configuracion_Utilidad.getInstancia(null).getGuardarDireccionPrimaria();
        File file = new File(savingPath + File.separator + "loggingError.txt");
        file.delete();
    }

    public void liberandoIngreso(Context context) {
        DeshabilitarIngreso();
        Configuracion_Utilidad config = Configuracion_Utilidad.getInstancia(context);
        File file = new File(config.getGuardarDireccionPrimaria() + File.separator + "ingresar.txt");
        try {
            buffescr = new BufferedWriter(new FileWriter(file, true));
            this.ingresar = true;
        } catch (IOException e) {
            e(this, e);
        }
    }
}
