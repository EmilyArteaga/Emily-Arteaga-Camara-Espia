
package com.jwork.arteaga.Capa_Datos;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.hardware.Camera;
import android.hardware.Camera.Size;
import android.media.AudioManager;
import android.media.CamcorderProfile;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.webkit.WebView;
import android.widget.Toast;

import com.jwork.arteaga.Capa_Negocio.Configuracion_Utilidad;
import com.jwork.arteaga.R;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Utilidades {

    private static final CharSequence MODEL_NAME_HTC_WILDFIRE = "HTC Wildfire";
    private static UtilidadInicio inicio = UtilidadInicio.getInstancia();
    private static Context context;

    public static String[] tamanioCamaraSoportado(Camera.Parameters parametrosCamara, StringBuffer dato) {
        List<Size> tamanios = parametrosCamara.getSupportedPreviewSizes();
        List<Size> tamanios2 = parametrosCamara.getSupportedPictureSizes();
        List<String> listaImagenes = new ArrayList<String>();
        for (Size size : tamanios2) {
            String temp = size.width + "x" + size.height + "*";
            dato.append(temp);
            dato.append("#");
            listaImagenes.add(temp);
        }
        for (Size size : tamanios) {
            if (android.os.Build.MODEL.contains(MODEL_NAME_HTC_WILDFIRE) && size.width == 1280) {
                continue;
            }
            String temp = size.width + "x" + size.height;
            dato.append(temp);
            dato.append("#");
            listaImagenes.add(temp);
        }
        dato.delete(dato.length() - 1, dato.length());
        String[] arrayImagenes = new String[listaImagenes.size()];
        return listaImagenes.toArray(arrayImagenes);
    }

    @TargetApi(11)
    public static String[] ordenSoporteCamara(int idCamara, StringBuffer dato) {
        ArrayList<String> lista = new ArrayList<String>();

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB || CamcorderProfile.hasProfile(idCamara, CamcorderProfile.QUALITY_LOW)) {
            lista.add("" + CamcorderProfile.QUALITY_LOW);
            dato.append("" + CamcorderProfile.QUALITY_LOW);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB && CamcorderProfile.hasProfile(idCamara, CamcorderProfile.QUALITY_QCIF)) {
            lista.add("" + CamcorderProfile.QUALITY_QCIF);
            dato.append("#" + CamcorderProfile.QUALITY_QCIF);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1 && CamcorderProfile.hasProfile(idCamara, CamcorderProfile.QUALITY_QVGA)) {
            lista.add("" + CamcorderProfile.QUALITY_QVGA);
            dato.append("#" + CamcorderProfile.QUALITY_QVGA);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            if (CamcorderProfile.hasProfile(idCamara, CamcorderProfile.QUALITY_CIF)) {
                lista.add("" + CamcorderProfile.QUALITY_CIF);
                dato.append("#" + CamcorderProfile.QUALITY_CIF);
            }
            if (CamcorderProfile.hasProfile(idCamara, CamcorderProfile.QUALITY_480P)) {
                lista.add("" + CamcorderProfile.QUALITY_480P);
                dato.append("#" + CamcorderProfile.QUALITY_480P);
            }
            if (CamcorderProfile.hasProfile(idCamara, CamcorderProfile.QUALITY_720P)) {
                lista.add("" + CamcorderProfile.QUALITY_720P);
                dato.append("#" + CamcorderProfile.QUALITY_720P);
            }
            if (CamcorderProfile.hasProfile(idCamara, CamcorderProfile.QUALITY_1080P)) {
                lista.add("" + CamcorderProfile.QUALITY_1080P);
                dato.append("#" + CamcorderProfile.QUALITY_1080P);
            }
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB || CamcorderProfile.hasProfile(idCamara, CamcorderProfile.QUALITY_HIGH)) {
            lista.add("" + CamcorderProfile.QUALITY_HIGH);
            dato.append("#" + CamcorderProfile.QUALITY_HIGH);
        }
        String[] cualidades = new String[lista.size()];
        lista.toArray(cualidades);
        return cualidades;
    }

    public static String crearReporteError(Throwable ex, Activity actividad, String infoAdicional) {
        StringBuffer reporte = new StringBuffer();
        StackTraceElement[] elemento = ex.getStackTrace();
        reporte.append("Porfavor ingrese la Descripcion. ");
        reporte.append("Ejemplo: La aplicacion se detuvo al tomar una foto");
        reporte.append("\n\n-------------------------------\n");
        reporte.append(ex.toString()).append("\n\n");
        reporte.append("--------- Rastro de Pila ---------\n");
        for (int i = 0; i < elemento.length; i++) {
            reporte.append("    ").append(elemento[i].toString()).append("\n");
        }
        reporte.append("-------------------------------\n\n");

        reporte.append("--------- Cause ---------\n");
        Throwable cause = ex.getCause();
        if (cause != null) {
            reporte.append(cause.toString()).append("\n");
            elemento = cause.getStackTrace();
            for (int i = 0; i < elemento.length; i++) {
                reporte.append("    ").append(elemento[i].toString()).append("\n");
            }
        }
        reporte.append("-------------------------------\n\n");
        reporte.append(getInformacionTelefono(actividad));
        reporte.append("-------------------------------\n");
        reporte.append(infoAdicional).append("\n");
        reporte.append("-------------------------------\n");
        return reporte.toString();
    }

    public static String getInformacionTelefono(Context actividad) {
        return "version App: " + actividad.getString(R.string.app_versionName) + "(" + getVersion(actividad) + ")" + '\n' + "Modelo Telefono: " + Build.MODEL + '\n' + "Version Android: " + Build.VERSION.RELEASE + '\n' + "Pizarra: " + Build.BOARD + '\n' + "Marca: " + Build.BRAND + '\n' + "Dispositivo: " + Build.DEVICE + '\n' + "Host: " + Build.HOST + '\n' + "ID: " + Build.ID + '\n' + "Producto: " + Build.PRODUCT + '\n' + "Tipo: " + Build.TYPE + '\n';
    }

    public static int getVersion(Context actividad) {
        int vers = 0;
        try {
            vers = actividad.getPackageManager().getPackageInfo(actividad.getPackageName(), 0).versionCode;
        } catch (NameNotFoundException e) {
        }
        return vers;
    }

    public static void Compartir(Context contexto) {
        Intent intentoTexto = new Intent(Intent.ACTION_SEND);
        intentoTexto.setType("texto/evidente");
        intentoTexto.putExtra(Intent.EXTRA_SUBJECT, "Camara Espia Emily Arteaga");
        intentoTexto.putExtra(Intent.EXTRA_TEXT,
                "Programacion 3 Universidad de Cuenca" + contexto.getPackageName());
    }

    public static boolean mostrarCambiarLogo(boolean chequeo, final Activity activity, boolean resetearConfiguracion) {
        final Configuracion_Utilidad configuracion = Configuracion_Utilidad.getInstancia(activity);
        String version = configuracion.getAppVersion();
        if (!chequeo || (chequeo && !version.equals(activity.getString(R.string.app_versionName)))) {
            if (resetearConfiguracion) {
                configuracion.configuracionNuevaVersion();
            }

            AlertDialog dialogo = new AlertDialog.Builder(activity).create();
            dialogo.setTitle("Changelog");

            WebView vistaWeb = new WebView(activity.getApplicationContext());
            vistaWeb.loadData(activity.getString(R.string.changelog_dialog_text), "text/html", "utf-8");
            vistaWeb.setScrollContainer(true);
            dialogo.setView(vistaWeb);

            dialogo.setButton(AlertDialog.BUTTON_NEGATIVE, activity.getString(android.R.string.ok), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    configuracion.setAppVersion(activity.getString(R.string.app_versionName));
                    dialog.dismiss();
                }
            });
            dialogo.setButton(AlertDialog.BUTTON_POSITIVE, "Calificar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    configuracion.setAppVersion(activity.getString(R.string.app_versionName));
                    dialog.dismiss();
                    Uri url = Uri.parse("DetallesId" + activity.getPackageName());
                    Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, url);
                    try {
                        activity.startActivity(myAppLinkToMarket);
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(activity, "Falló la Aplicacion", Toast.LENGTH_LONG).show();
                    }
                }
            });
            dialogo.setButton(AlertDialog.BUTTON_NEUTRAL, "Donar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    configuracion.setAppVersion(activity.getString(R.string.app_versionName));
                    dialog.dismiss();
                    //					Utilidades.Compartir(activity);
                    abrirDonaciones(activity);
                }
            });
            dialogo.show();
            return true;
        }
        return false;
    }

    public static String getDireccionTarjetaExterna() {
        BufferedReader bufflectu = null;
        String primario = Environment.getExternalStorageDirectory().getPath();
        String resultado = null;
        try {
            bufflectu = new BufferedReader(new FileReader(new File("/etc/vold.fstab")));
            String linea;
            while ((linea = bufflectu.readLine()) != null) {
                linea = linea.trim();
                if (linea.startsWith("#")) {
                    continue;
                } else {
                    String[] dato = linea.split(" ");
                    if (dato.length < 3) {
                        continue;
                    }
                    if (!dato[0].equalsIgnoreCase("dev_mount")) {
                        continue;
                    }
                    if (!dato[1].contains("sdcard")) {
                        continue;
                    }
                    if (dato[2].equalsIgnoreCase(primario)) {
                        continue;
                    }
                    resultado = dato[2];
                    break;
                }
            }
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            try {
                bufflectu.close();
            } catch (Exception e) {
            }
        }
        inicio.v(Utilidades.class, "getDireccionTarjetaExterna():" + resultado);
        return resultado;
    }

    public static void setSonido(Context contexto, int mode) {
        inicio.d(Utilidades.class, "setSonido(mode:" + mode + ")");
        if (contexto != null) {
            AudioManager manager = (AudioManager) contexto.getSystemService(Context.AUDIO_SERVICE);
            manager.setRingerMode(mode);
        }
    }

    public static int getSonido(Context contexto) {
        inicio.d(Utilidades.class, "getSonido()");
        AudioManager manager = (AudioManager) contexto.getSystemService(Context.AUDIO_SERVICE);
        return manager.getRingerMode();
    }

    public static void abrirDonaciones(Context contexto) {
        Intent inte = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.ucuenca.edu.ec/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=ZPQBLUCBZ99Z4"));
        contexto.startActivity(inte);
    }

    public static boolean estaLinea(Context contexto) {
        ConnectivityManager conectividad = (ConnectivityManager) contexto.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (conectividad != null) {
            NetworkInfo infoNet = conectividad.getActiveNetworkInfo();
            if (infoNet != null && infoNet.isConnectedOrConnecting()) {
                return true;
            }
        }
        return false;
    }

    public static Context getContextoGlobal() {
        return context;
    }

    public static void setContextoGlobal(Context contexto) {
        Utilidades.context = contexto;
    }

}
