
package com.jwork.arteaga.Capa_Negocio;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RemoteViews;
import android.widget.Spinner;
import android.widget.Toast;

import com.jwork.arteaga.Capa_Datos.ProveedorCamara;
import com.jwork.arteaga.Capa_Datos.UtilidadInicio;
import com.jwork.arteaga.R;

public class ConfiguracionCamara extends Activity {

    private UtilidadInicio inciar = UtilidadInicio.getInstancia();
    private int AppAjusteId = -1;
    private Spinner AccionHilo;
    private EditText textito;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        inciar.v(this, "onCreate");

        setContentView(R.layout.widget_configure);
        AccionHilo = (Spinner) findViewById(R.id.widgetAction);
        textito = (EditText) findViewById(R.id.widgetText);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            AppAjusteId = extras.getInt(
                    AppWidgetManager.EXTRA_APPWIDGET_ID,
                    AppWidgetManager.INVALID_APPWIDGET_ID);
        }
        inciar.d(this, "AppAjusteId: " + AppAjusteId);
    }

    public void enClickOk(View view) {
        inciar.v(this, "enClickOk");

        int accion = AccionHilo.getSelectedItemPosition();
        if (accion == 3 && Build.VERSION.SDK_INT < Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
            Toast.makeText(this, "Facedetection is only supported for Android 4.0 or newer", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent valorResultado = new Intent();
        valorResultado.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppAjusteId);

        Configuracion_Utilidad preferencias = Configuracion_Utilidad.getInstancia(getApplicationContext());
        preferencias.setConfiguarcionAjustes(AppAjusteId, accion, textito.getText().toString());

        setResult(RESULT_OK, valorResultado);

        AppWidgetManager appAjusteManager = AppWidgetManager.getInstance(getApplicationContext());
        RemoteViews vistas = new RemoteViews(getApplicationContext().getPackageName(),
                R.layout.widget_camera);
        appAjusteManager.updateAppWidget(AppAjusteId, vistas);
        ProveedorCamara.updateAppWidget(this, appAjusteManager, AppAjusteId);

        finish();
    }

    public void enClickCancelar(View view) {
        inciar.v(this, "enClickCancelar");
        setResult(RESULT_CANCELED);
        finish();
    }

}
