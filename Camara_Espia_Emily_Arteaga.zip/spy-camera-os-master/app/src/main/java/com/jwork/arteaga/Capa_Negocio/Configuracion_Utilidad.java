
package com.jwork.arteaga.Capa_Negocio;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.media.CamcorderProfile;
import android.os.Environment;
import android.preference.PreferenceManager;

import com.jwork.arteaga.Capa_Datos.UtilidadInicio;
import com.jwork.arteaga.Capa_Datos.Utilidades;
import com.jwork.arteaga.R;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Configuracion_Utilidad {

    public static final String PREF_VISTA_PREVIA = "vistaPrevia";
    public static final String AUTO_TOMADO = "AutoTomado";
    public static final String MOSTRAR_BRINDADO = "mostrarBrindado";
    public static final String PREFERENCIA_TAMANIO_IMAGEN = "tamanioImagen-";
    public static final String PREFERENCIA_TAMANIO_0 = "tamanioImagen-0";
    public static final String PREFERENCIA_TAMANIO_1 = "tamanioImagen-1";
    public static final String CAMARA_ID = "camaraId";
    public static final String AVANCE_EN_AUTO_TOMADO = "avance en Displey de Tomado";
    public static final String PREFERENCIAS_COLISIONES = "solo Colisionó";
    public static final String PREFERENCIA_VERSION_APP = "Version App";
    public static final String PREFERENCIA_CARPETA_ESCONDIDA = "Esconder Carpeta";
    public static final String PREFERENCIA_VIBRACION = "vibracion";
    public static final String PREFERENCIA_AVANCE_TAMANIO = "AvancesTamaniosCamera-";
    public static final String PREFERENCIA_REPORTE_ERRORES = "OrientacionDelDisplay";
    public static final String PREFERENCIA_VIDEO_CALIDAD = "CalidadVideo-";
    public static final String PREFERENCIA_CALIDAD_0 = "CalidadVideo-0";
    public static final String PREFERENCIA_CALIDAD_1 = "CalidadVideo-1";
    public static final String PREFERENCIA_CALIDAD_VIDEO_LISTA = "CalidadVideoLista-";
    public static final String PREFERENCIA_CALIDAD_VIDEO_LISTA_0 = "CalidadVideoList-0";
    public static final String PREFERENCIA_CALIDAD_VIDEO_LISTA_1 = "CalidadVideoList-1";
    public static final String USAR_AUTOENFOCADO_2 = "usarAutoEnfocado2";
    public static final String NOTICIA_EXPERIMENTAL = "NoticiaExperimental";
    public static final String TIEMPO_DE_VIBRADO = "TiempoVibrado";
    public static final String GUARDAR_DIRECTORIO = "GuardandoDDirectorio";
    public static final String GUARDAR_DIRECTORIO_EXTERNO = "GuardandoDirectorioExterno";
    public static final String OPCIONES_VOLUMEN_ARRIBA = "AccionVolumenArriba";
    public static final String OPCIONES_VOLUMEN_ABAJO = "AccionVolumenAbajo";
    public static final String INGRESADO = "ingresado";
    public static final String INICIAR_MODO_NEGRO = "IniciarModoNegro";
    private static final String[] RESETEO = new String[]{
            PREF_VISTA_PREVIA, PREFERENCIA_TAMANIO_0, PREFERENCIA_TAMANIO_1, CAMARA_ID
            , PREFERENCIA_CALIDAD_0, PREFERENCIA_CALIDAD_1, PREFERENCIA_CALIDAD_VIDEO_LISTA_0, PREFERENCIA_CALIDAD_VIDEO_LISTA_1
            , INICIAR_MODO_NEGRO
    };
    public static final String PREFERENCIA_BOTON_AJUSTE = "accionAjuste-";
    public static final String PREFERENCIA_AJUSTE_TEXTO = "ajusteTexto-";
    public static final String PREFERENCIA_ROTAR_IMAGEN = "rotacionImagen";
    public static final String YUV_DECODE_ALTERNATIVO = "yuvDecodeAlternativo";
    public static final String PREFERENCIA_MINIMIZAR_EXPERIMENTAL = "esperimentalMinimizar";
    public static final String DESABILIDAR_SERVICIO_BACKUP = "DeshabilitarServicio";
    public static final String PREFERENCIA_EMAIL_HABILITADO = "autoGmailHabilitado";
    public static final String PREFERENCIA_EMAIL_RECIBIDO = "autoGmailRecibido";
    public static final String PREFERENCIA_EMAIL_NOMBRE_USUARIO = "gmailUsuario";
    public static final String PREFERENCIA_EMAIL_CONTRASENIA = "gmailContrasenia";
    public static final String PREFERENCIA_INICIAR_APP_ULTIMOINGRESO = "iniciarUltimoIngreso";
    public static Configuracion_Utilidad instancia;
    private SharedPreferences preferencia;
    private Context contexto;
    private UtilidadInicio iniciar;
    private Integer avanceTamanioImagen = null;
    private Boolean mostrartoast = null;
    private Boolean usarAutoEnfocado = null;
    private Integer autoCapturar = null;
    private Boolean vibrar = null;
    private Long tiempoVibrar = null;
    private String guardarDireccion = null;
    private String guardarDireccionPrimaria = null;
    private Boolean ingresando = null;
    private Boolean deshabilitarSevicioBackground = null;
    private Boolean autoGmailHabilitado = null;
    private String autoGMailRecivido = null;
    private String autoGmailUsuario = null;
    private String autoGmailContrasenia = null;

    private Configuracion_Utilidad(Context contexto) {
        this.contexto = contexto;
        PreferenceManager.setDefaultValues(contexto, R.xml.setting, false);
        this.preferencia = PreferenceManager.getDefaultSharedPreferences(this.contexto);
        this.iniciar = UtilidadInicio.getInstancia();

        if (getGuardarDireccion() == null) {
            setGuardarDireccion(getGuardarDireccionPrimaria());
        }
    }

    public synchronized static Configuracion_Utilidad getInstancia(Context contexto) {
        if (instancia == null) {
            instancia = new Configuracion_Utilidad(contexto);
        }
        return instancia;
    }

    public synchronized static Configuracion_Utilidad createInstance(Context contexto) {
        return new Configuracion_Utilidad(contexto);
    }

    public int getAvanceTamanioImagen() {
        if (avanceTamanioImagen == null) {
            avanceTamanioImagen = preferencia.getInt(PREF_VISTA_PREVIA, 150);
        }
        iniciar.v(this, "getAvanceTamanioImagen():" + avanceTamanioImagen);
        return avanceTamanioImagen;
    }

    public void setAvanceTamanioImagen(int width) {
        iniciar.v(this, "setAvanceTamanioImagen(width:" + width + ")");
        preferencia.edit().putInt(PREF_VISTA_PREVIA, width).commit();
        avanceTamanioImagen = width;
    }

    public int getCamaraCorriente() {
        int dato = 0;
        String temp = preferencia.getString(CAMARA_ID, "0");
        try {
            dato = Integer.parseInt(temp);
        } catch (NumberFormatException e) {
        }
        iniciar.v(this, "getCamaraCorriente():" + dato);
        return dato;
    }

    public void setCamaraCorriente(int cameraId) {
        iniciar.v(this, "setCamaraCorriente(cameraId:" + cameraId + ")");
        preferencia.edit().putString(CAMARA_ID, "" + cameraId).commit();
    }

    public String getTamaniosPrevios(int cameraId) {
        String dato = preferencia.getString(PREFERENCIA_AVANCE_TAMANIO + cameraId, null);
        iniciar.v(this, "getTamaniosPrevios(cameraId:" + cameraId + "):" + dato);
        return dato;
    }

    public void setCamaraTamaniosPrevios(int cameraId, String data) {
        iniciar.v(this, "setCamaraTamaniosPrevios(cameraId:" + cameraId + "|data:" + data + ")");
        preferencia.edit().putString(PREFERENCIA_AVANCE_TAMANIO + cameraId, data).commit();
    }

    public String getListaCalidadVideo(int cameraId) {
        String dato = preferencia.getString(PREFERENCIA_CALIDAD_VIDEO_LISTA + cameraId, null);
        iniciar.v(this, "getListaCalidadVideo(cameraId:" + cameraId + "):" + dato);
        return dato;
    }

    public void setListaCalidadVideo(int cameraId, String data) {
        iniciar.v(this, "setListaCalidadVideo(cameraId:" + cameraId + "|data:" + data + ")");
        preferencia.edit().putString(PREFERENCIA_CALIDAD_VIDEO_LISTA + cameraId, data).commit();
    }

    public String getTamanioImagenCapturada(int cameraId) {
        String data = preferencia.getString(PREFERENCIA_TAMANIO_IMAGEN + cameraId, null);
        iniciar.v(this, "getTamanioImagenCapturada(cameraId:" + cameraId + "):" + data);
        return data;
    }

    public void setTamanioImagenCapturada(int cameraId, String data) {
        iniciar.v(this, "setTamanioImagenCapturada(cameraId:" + cameraId + "|data:" + data + ")");
        preferencia.edit().putString(PREFERENCIA_TAMANIO_IMAGEN + cameraId, data).commit();
    }

    public int getCalidadVideoGrabado(int cameraId) {
        String temp = preferencia.getString(PREFERENCIA_VIDEO_CALIDAD + cameraId, "" + CamcorderProfile.QUALITY_HIGH);
        int dato = CamcorderProfile.QUALITY_HIGH;
        try {
            dato = Integer.parseInt(temp);
        } catch (NumberFormatException e) {
        }
        iniciar.v(this, "getCalidadVideoGrabado(cameraId:" + cameraId + "):" + dato);
        return dato;
    }

    public void setCalidadVideoGrabado(int cameraId, int data) {
        iniciar.v(this, "setCalidadVideoGrabado(cameraId:" + cameraId + "|data:" + data + ")");
        preferencia.edit().putString(PREFERENCIA_VIDEO_CALIDAD + cameraId, "" + data).commit();
    }

    public boolean MostrarToast() {
        if (mostrartoast == null) {
            mostrartoast = preferencia.getBoolean(MOSTRAR_BRINDADO, true);
        }
        iniciar.v(this, "MostrarToast():" + mostrartoast);
        return mostrartoast;
    }

    public void limpiar(boolean isUncaughtExc) {
        Editor editor = preferencia.edit();
        for (String llave : RESETEO) {
            editor.remove(llave);
        }
        if (isUncaughtExc) {
            editor.putBoolean(PREFERENCIAS_COLISIONES, true);
        }
        editor.commit();
    }

    public void ponerBooleano(String id, boolean data) {
        iniciar.v(this, "ponerBooleano(id:" + id + "|data:" + data + ")");
        preferencia.edit().putBoolean(id, data).commit();
    }

    public boolean getBooleano(String id, boolean b) {
        boolean data = preferencia.getBoolean(id, b);
        iniciar.v(this, "getBooleano(id" + id + "):" + data);
        return data;
    }

    public boolean getUsarAutoEnfocado() {
        if (usarAutoEnfocado == null) {
            usarAutoEnfocado = preferencia.getBoolean(USAR_AUTOENFOCADO_2, false);
        }
        iniciar.v(this, "getUsarAutoEnfocado():" + usarAutoEnfocado);
        return usarAutoEnfocado;
    }

    public int getAutoCapturar() {
        if (autoCapturar == null) {
            autoCapturar = 2000;
            try {
                autoCapturar = Integer.parseInt(preferencia.getString(AUTO_TOMADO, "2000"));
            } catch (NumberFormatException e) {
            }
        }
        return autoCapturar;
    }

    public boolean estaNoticiaExperimentado() {
        boolean data = preferencia.getBoolean(NOTICIA_EXPERIMENTAL, false);
        iniciar.v(this, "estaNoticiaExperimentado():" + data);
        return data;
    }

    public void setNoticiaExperimental() {
        iniciar.v(this, "setNoticiaExperimental()");
        preferencia.edit().putBoolean(NOTICIA_EXPERIMENTAL, true).commit();
    }

    public boolean estaColisionado() {
        boolean data = preferencia.getBoolean(PREFERENCIAS_COLISIONES, false);
        iniciar.v(this, "estaColisionado():" + data);
        return data;
    }

    public void limpiarColisionado() {
        iniciar.v(this, "limpiarColisionado()");
        preferencia.edit().remove(PREFERENCIAS_COLISIONES).commit();
    }

    public String getDireccionColision() {
        return getGuardarDireccionPrimaria() + "/stack.trace";
    }

    public String getDireccionTipoColision() {
        return getGuardarDireccionPrimaria() + "/SpyCamera/error.trace";
    }

    public boolean getVibrar() {
        if (vibrar == null) {
            vibrar = preferencia.getBoolean(PREFS_VIBRATION, true);
        }
        iniciar.v(this, "getVibrar():" + vibrar);
        return vibrar;
    }

    public long getTiempoVibrar() {
        if (tiempoVibrar == null) {
            tiempoVibrar = preferencia.getLong(TIEMPO_DE_VIBRADO, 100);
        }
        iniciar.v(this, "getTiempoVibrar():" + tiempoVibrar);
        return tiempoVibrar;
    }

    public boolean estaOcultaCarpeta() {
        boolean dato = preferencia.getBoolean(PREFERENCIA_CARPETA_ESCONDIDA, false);
        iniciar.v(this, "estaOcultaCarpeta():" + dato);
        return dato;
    }

    public void registrarEnCambioCompartido(OnSharedPreferenceChangeListener listener) {
        preferencia.registerOnSharedPreferenceChangeListener(listener);
    }

    public void dejarRegistrarEnCambioCompartido(OnSharedPreferenceChangeListener listener) {
        preferencia.unregisterOnSharedPreferenceChangeListener(listener);
    }

    public String getAppVersion() {
        String dato = preferencia.getString(PREFERENCIA_VERSION_APP, "");
        iniciar.v(this, "getAppVersion():" + dato);
        return dato;
    }

    public void setAppVersion(String version) {
        iniciar.v(this, "setAppVersion(version:" + version + ")");
        preferencia.edit().putString(PREFERENCIA_VERSION_APP, version).commit();
    }

    public void configuracionNuevaVersion() {
        iniciar.v(this, "configuracionNuevaVersion()");
        Editor editor = preferencia.edit();
        editor.remove(PREFERENCIA_AVANCE_TAMANIO + "0");
        editor.remove(PREFERENCIA_AVANCE_TAMANIO + "1");
        editor.remove(PREFERENCIA_CALIDAD_VIDEO_LISTA + "0");
        editor.remove(PREFERENCIA_CALIDAD_VIDEO_LISTA + "1");
        editor.remove(GUARDAR_DIRECTORIO_EXTERNO);
        editor.remove(INICIAR_MODO_NEGRO);
        editor.commit();
    }

    public String getGuardarDireccion() {
        if (guardarDireccion == null) {
            guardarDireccion = preferencia.getString(GUARDAR_DIRECTORIO, getGuardarDireccionPrimaria());
        }
        iniciar.v(this, "getGuardarDireccion():" + guardarDireccion);
        return guardarDireccion;
    }

    public void setGuardarDireccion(String path) {
        iniciar.v(this, "setGuardarDireccion(path:" + path + ")");
        preferencia.edit().putString(GUARDAR_DIRECTORIO, path).commit();
        guardarDireccion = path;
    }

    public String getGuardarDireccionPrimaria() {
        if (guardarDireccionPrimaria == null) {
            guardarDireccionPrimaria = Environment.getExternalStorageDirectory().getPath() + "/SpyCamera";
        }
        iniciar.v(this, "getGuardarDireccionPrimaria():" + guardarDireccionPrimaria);
        return guardarDireccionPrimaria;
    }

    public String getGuardarDireccionExterna() {
        String dato = preferencia.getString(GUARDAR_DIRECTORIO_EXTERNO, null);
        if (dato == null) {
            dato = Utilidades.getDireccionTarjetaExterna();
            if (dato != null) {
                dato += "/SpyCamera";
                preferencia.edit().putString(GUARDAR_DIRECTORIO_EXTERNO, dato).commit();
            }
        }
        iniciar.v(this, "getGuardarDireccionExterna():" + dato);
        return dato;
    }

    public String getAccionVolumenAbajo() {
        String dato = preferencia.getString(OPCIONES_VOLUMEN_ABAJO, "capture");
        iniciar.v(this, "getAccionVolumenAbajo():" + dato);
        return dato;
    }

    public String getAccionVolumenArriba() {
        String dato = preferencia.getString(OPCIONES_VOLUMEN_ARRIBA, "auto");
        iniciar.v(this, "getAccionVolumenArriba():" + dato);
        return dato;
    }

    public boolean getIngresando() {
        if (ingresando == null) {
            ingresando = preferencia.getBoolean(INGRESADO, true);
        }
        iniciar.v(this, "getIngresando():" + ingresando);
        return ingresando;
    }

    public boolean estaEnModoNegro() {
        boolean data = preferencia.getBoolean(INICIAR_MODO_NEGRO, false);
        iniciar.v(this, "estaEnModoNegro():" + data);
        return data;
    }

    public void resetear() {
        this.autoCapturar = null;
        this.ingresando = null;
        this.avanceTamanioImagen = null;
        this.guardarDireccion = null;
        this.guardarDireccionPrimaria = null;
        this.mostrartoast = null;
        this.usarAutoEnfocado = null;
        this.vibrar = null;
        this.tiempoVibrar = null;
        this.deshabilitarSevicioBackground = null;
        this.autoGmailHabilitado = null;
        this.autoGMailRecivido = null;
        this.autoGmailUsuario = null;
        this.autoGmailContrasenia = null;
    }

    public void setConfiguarcionAjustes(int id,
                                        int action, String text) {
        iniciar.v(this, "setConfiguarcionAjustes(id:" + id + "|action:" + action + "|text:" + text + ")");
        preferencia.edit().putInt(PREFERENCIA_BOTON_AJUSTE + id, action).commit();
        preferencia.edit().putString(PREFERENCIA_AJUSTE_TEXTO + id, text).commit();
    }

    public void eleminarConfiguracionAjuste(int id) {
        iniciar.v(this, "clearWidgetConfiguration(id:" + id + ")");
        preferencia.edit().remove(PREFERENCIA_BOTON_AJUSTE + id).commit();
        preferencia.edit().remove(PREFERENCIA_AJUSTE_TEXTO + id).commit();
    }

    public int getAccionConfiguracionAjuste(int id) {
        int dato = preferencia.getInt(PREFERENCIA_BOTON_AJUSTE + id, -1);
        iniciar.v(this, "getAccionConfiguracionAjuste(id:" + id + "):" + dato);
        return dato;
    }

    public String getConfiguracionTextoAjuste(int id) {
        String dato = preferencia.getString(PREFERENCIA_AJUSTE_TEXTO + id, "default");
        iniciar.v(this, "getConfiguracionTextoAjuste(id:" + id + "):" + dato);
        return dato;
    }

    public int getRotacionImagen() {
        int dato = 0;
        try {
            dato = Integer.parseInt(preferencia.getString(PREFERENCIA_ROTAR_IMAGEN, "0"));
        } catch (NumberFormatException e) {
        }
        iniciar.v(this, "getRotacionImagen():" + dato);
        return dato;
    }

    public void setRotacionImagen(int rotation) {
        iniciar.v(this, "setRotacionImagen(rotation:" + rotation + ")");
        preferencia.edit().putString(PREFERENCIA_ROTAR_IMAGEN, "" + rotation).commit();
    }

    public boolean estaYUVDecodeAlternativo() {
        boolean dato = preferencia.getBoolean(YUV_DECODE_ALTERNATIVO, false);
        iniciar.v(this, "estaYUVDecodeAlternativo():" + dato);
        return dato;
    }

    public boolean estaExperimentalMinimizado() {
        boolean dato = preferencia.getBoolean(PREFERENCIA_MINIMIZAR_EXPERIMENTAL, false);
        iniciar.v(this, "estaExperimentalMinimizado():" + dato);
        return dato;
    }

    public void setExperimentalMinimizado() {
        iniciar.v(this, "setExperimentalMinimizado()");
        preferencia.edit().putBoolean(PREFERENCIA_MINIMIZAR_EXPERIMENTAL, true).commit();
    }

    public boolean getDeshabilitarSevicioBackground() {
        if (deshabilitarSevicioBackground == null) {
            deshabilitarSevicioBackground = preferencia.getBoolean(DESABILIDAR_SERVICIO_BACKUP, false);
        }
        iniciar.v(this, "getDeshabilitarSevicioBackground():" + deshabilitarSevicioBackground);
        return deshabilitarSevicioBackground;
    }

    public boolean estaHabilitadoGmail() {
        if (autoGmailHabilitado == null) {
            autoGmailHabilitado = preferencia.getBoolean(PREFERENCIA_EMAIL_HABILITADO, false);
        }
        iniciar.v(this, "estaHabilitadoGmail():" + autoGmailHabilitado);
        return autoGmailHabilitado;
    }

    public String getAutoGMailRecivido() {
        if (autoGMailRecivido == null) {
            autoGMailRecivido = preferencia.getString(PREFERENCIA_EMAIL_RECIBIDO, "");
        }
        iniciar.v(this, "getAutoGMailRecivido():" + autoGMailRecivido);
        return autoGMailRecivido;
    }

    public String getAutoGmailUsuario() {
        if (autoGmailUsuario == null) {
            autoGmailUsuario = preferencia.getString(PREFERENCIA_EMAIL_NOMBRE_USUARIO, "");
        }
//		iniciar.v(this, "getAutoGmailUsuario():"+autoGmailUsuario);
        return autoGmailUsuario;
    }

    public String getAutoGmailContrasenia() {
        if (autoGmailContrasenia == null) {
            autoGmailContrasenia = preferencia.getString(PREFERENCIA_EMAIL_CONTRASENIA, "");
        }
//		iniciar.v(this, "getAutoGmailContrasenia():"+autoGmailContrasenia);
        return autoGmailContrasenia;
    }

    public void setIniciarAppInicio() {
        String dia = SimpleDateFormat.getDateInstance(SimpleDateFormat.SHORT).format(new Date());
        iniciar.v(this, "setIniciarAppInicio():" + dia);
        preferencia.edit().putString(PREFERENCIA_INICIAR_APP_ULTIMOINGRESO, dia).commit();
    }

    public boolean estaAppInicioHoy() {
        boolean dato = false;
        String date = SimpleDateFormat.getDateInstance(SimpleDateFormat.SHORT).format(new Date());
        if (preferencia.getString(PREFERENCIA_INICIAR_APP_ULTIMOINGRESO, "").equals(date)) {
            dato = true;
        }
        iniciar.v(this, "estaAppInicioHoy():" + dato);
        return dato;
    }

}
