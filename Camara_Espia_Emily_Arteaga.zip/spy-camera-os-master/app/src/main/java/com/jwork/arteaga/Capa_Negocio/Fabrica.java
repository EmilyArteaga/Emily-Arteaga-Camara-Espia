
package com.jwork.arteaga.Capa_Negocio;

import android.app.Activity;
import android.os.Handler;

import com.jwork.arteaga.Main_Controlador;
import com.jwork.arteaga.Main_Fragmentos;
import com.jwork.arteaga.Main_Principal;

public class Fabrica {

    private static Fabrica instancia = null;
    private Main_Principal mainPrincipal;
    private Main_Controlador mainControlador;

    public static void reset() {
        instancia = null;
    }

    public synchronized static Fabrica getInstancia() {
        if (instancia == null) {
            instancia = new Fabrica();
        }
        return instancia;
    }

    public synchronized Main_Principal getMainFragmentos(Main_Fragmentos mainFragmentos) {
        if (mainPrincipal == null) {
            mainPrincipal = new Main_Principal(mainFragmentos);
        } else {
            mainPrincipal.setFragment(mainFragmentos);
        }
        return mainPrincipal;
    }

    public synchronized Main_Controlador getMainControlador(Activity activity,
                                                            Handler handler) {
        if (mainControlador == null) {
            mainControlador = new Main_Controlador(activity, handler);
        } else {
            mainControlador.setActividad(activity);
            mainControlador.setUIManejador(handler);
        }
        return mainControlador;
    }

}
