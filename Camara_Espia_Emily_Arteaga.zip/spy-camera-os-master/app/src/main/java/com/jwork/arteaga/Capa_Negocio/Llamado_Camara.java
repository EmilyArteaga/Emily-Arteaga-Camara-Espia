
package com.jwork.arteaga.Capa_Negocio;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;

import com.jwork.arteaga.Capa_Datos.UtilidadInicio;
import com.jwork.arteaga.Main_Controlador;
import com.jwork.arteaga.Notificaciones;
import com.jwork.arteaga.R;

public class Llamado_Camara extends Service {

    public static final String EXTRA_MESSENGER = "MESSENGER";
    public static final String EXTRA_TYPE = "TIPO";
    public static final String EXTRA_ACTION = "ACCION";
    public static final String NAME = "ServicioCamara";

    public static final int QUE_DETIENE = 0;
    public static int estado = QUE_DETIENE;
    public static final int QUE_INICIA_AUTOTOMADO = 1;
    public static final int QUE_INICIA_TOMADO_CARA = 2;
    public static final int QUE_INICIA_GRABACION_VIDEO = 3;
    public static final int NOTIFICACION_ID = 1;
    private UtilidadInicio iniciar = UtilidadInicio.getInstancia();
    private boolean corriendo = false;
    private AsyncTask<Integer, ?, ?> tarea = null;
    private Messenger fueraMessenger;

    public static void setEstado(int estado) {
        Llamado_Camara.estado = estado;
    }

    @Override
    public int onStartCommand(Intent intento, int bandera, int iniciarID) {
        iniciar.v(this, "ElComandoDeInicio(InciandoId:" + iniciarID + ")");
        if (intento == null) {
            iniciar.w(this, "Falló la ejecución");
            Toast.makeText(this, "Falló la ejecución", Toast.LENGTH_LONG).show();
            stopSelf();
            return START_NOT_STICKY;
        }
        int accion = intento.getIntExtra(EXTRA_ACTION, -1);
        fueraMessenger = (Messenger) intento.getExtras().get(EXTRA_MESSENGER);
        switch (accion) {
            case QUE_INICIA_AUTOTOMADO:
                iniciarAutoTomado();
                break;
            case QUE_INICIA_TOMADO_CARA:
                inciarCaraTomado();
                break;
            case QUE_INICIA_GRABACION_VIDEO:
                inciarGrabacionVideo();
                break;
        }
        return START_STICKY;
    }

    private void inciarGrabacionVideo() {
        Llamado_Camara.setEstado(QUE_INICIA_GRABACION_VIDEO);
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(NOTIFICACION_ID, crearNOtificacionDetener("Corriendo"));
        Message backMsg = Message.obtain();
        backMsg.what = Main_Controlador.QUE_INICIAR_VIDEO;
        try {
            this.fueraMessenger.send(backMsg);
        } catch (android.os.RemoteException e1) {
            iniciar.w(this, e1);
        }

    }

    private void inciarCaraTomado() {
        Llamado_Camara.setEstado(QUE_INICIA_TOMADO_CARA);
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(NOTIFICACION_ID, crearNOtificacionDetener("Detectectando"));
        Message backMsg = Message.obtain();
        backMsg.what = Main_Controlador.QUE_INICIAR_TOMADO_CARA;
        try {
            this.fueraMessenger.send(backMsg);
        } catch (android.os.RemoteException e1) {
            iniciar.w(this, e1);
        }
    }

    @Override
    public void onDestroy() {
        iniciar.v(this, "Destruyendo()");
        super.onDestroy();
        corriendo = false;
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancel(NOTIFICACION_ID);

        if (estado == QUE_INICIA_AUTOTOMADO) {
            Message backMsg = Message.obtain();
            backMsg.what = Main_Controlador.QUE_DETENER_AUTO_TOMADO;
            try {
                fueraMessenger.send(backMsg);
            } catch (android.os.RemoteException e1) {
                iniciar.w(this, e1);
            }
        } else if (estado == QUE_INICIA_GRABACION_VIDEO) {
            Message backMsg = Message.obtain();
            backMsg.what = Main_Controlador.QUE_DETENER_VIDEO;
            try {
                fueraMessenger.send(backMsg);
            } catch (android.os.RemoteException e1) {
                iniciar.w(this, e1);
            }
        } else if (estado == QUE_INICIA_TOMADO_CARA) {
            Message backMsg = Message.obtain();
            backMsg.what = Main_Controlador.QUE_DETENER_TOMDO_CARA;
            try {
                fueraMessenger.send(backMsg);
            } catch (android.os.RemoteException e1) {
                iniciar.w(this, e1);
            }
        }
        setEstado(QUE_DETIENE);
    }

    private void iniciarAutoTomado() {
        corriendo = true;

        Notification notificacion = crearNOtificacionDetener("Auto");

        NotificationManager notificacionManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificacionManager.notify(NOTIFICACION_ID, notificacion);

        Message backMsg = Message.obtain();
        backMsg.what = Main_Controlador.QUE_INICIAR_AUTO_TOMADO;
        try {
            fueraMessenger.send(backMsg);
        } catch (android.os.RemoteException e1) {
            iniciar.w(this, e1);
        }
        Llamado_Camara.setEstado(QUE_INICIA_AUTOTOMADO);
        if (tarea != null) {
            tarea.cancel(true);
        }
        tarea = new AutoShootServiceAsync(fueraMessenger);
        tarea.execute(Configuracion_Utilidad.getInstancia(this).getAutoCapturar());

    }

    private Notification crearNOtificacionDetener(String lab) {
        Intent intento = new Intent(this, Notificaciones.class);
        intento.putExtra(EXTRA_TYPE, NAME);
        intento.putExtra(EXTRA_ACTION, QUE_DETIENE);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intento, 0);

        Notification notificaion = new NotificationCompat.Builder(this)
                .setContentTitle("SC-OS")
                .setContentText(lab)
                .setTicker("SC-OS: " + lab)
                .setAutoCancel(true)
                .setSmallIcon(R.drawable.io)
                .setContentIntent(pendingIntent)
                .build();
        return notificaion;
    }

    @Override
    public IBinder onBind(Intent intento) {
        iniciar.v(this, "onBind()");
        return null;
    }

    class AutoShootServiceAsync extends AsyncTask<Integer, Void, Void> {

        private Messenger messenger;

        public AutoShootServiceAsync(Messenger messenger) {
            this.messenger = messenger;
        }

        @Override
        protected Void doInBackground(Integer... params) {
            try {
                while (estado == QUE_INICIA_AUTOTOMADO && corriendo) {
                    iniciar.v(this, "HaciendoEnFondo(durmiendo:" + params[0] + ")");
                    Thread.sleep(params[0]);
                    if (estado == QUE_INICIA_AUTOTOMADO && corriendo) {
                        Message backMsg = Message.obtain();
                        backMsg.what = Main_Controlador.QUE_CONTINUAR_AUTO_TOMADO;
                        try {
                            messenger.send(backMsg);
                        } catch (android.os.RemoteException e1) {
                            iniciar.w(this, e1);
                        }
                    }
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

}
