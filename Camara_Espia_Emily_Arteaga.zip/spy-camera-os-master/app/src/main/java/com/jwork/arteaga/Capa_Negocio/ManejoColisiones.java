
package com.jwork.arteaga.Capa_Negocio;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

import com.jwork.arteaga.Capa_Datos.UtilidadInicio;
import com.jwork.arteaga.Capa_Datos.Utilidades;
import com.jwork.arteaga.Main_Controlador;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.lang.Thread.UncaughtExceptionHandler;

public class ManejoColisiones implements UncaughtExceptionHandler {

    private static ManejoColisiones instancia;
    private Activity actividad;
    private Configuracion_Utilidad preferencias;
    private UtilidadInicio iniciar;
    private UncaughtExceptionHandler defaultUEH;
    private Fabrica fabrica;

    private ManejoColisiones(Activity contexto, UncaughtExceptionHandler defaultUEH) {
        this.actividad = contexto;
        this.defaultUEH = defaultUEH;
        this.preferencias = Configuracion_Utilidad.getInstancia(contexto);
        this.iniciar = UtilidadInicio.getInstancia();
        this.fabrica = Fabrica.getInstancia();
    }

    public synchronized static ManejoColisiones getInstancia(Activity contexto, UncaughtExceptionHandler defaultUEH) {
        if (instancia == null) {
            instancia = new ManejoColisiones(contexto, defaultUEH);
        }
        return instancia;
    }

    @Override
    public void uncaughtException(Thread hilo, Throwable ex) {
        Main_Controlador controlador = null;
        Configuracion_Utilidad configuracion = Configuracion_Utilidad.getInstancia(null);
        try {
            iniciar.e(this, ex);
            iniciar.DeshabilitarIngreso();
            iniciar.eliminarRegistroErrores();
            iniciar.renombrarErrores();
            controlador = fabrica.getMainControlador(null, null);
            crearArchivoError(ex);
            File directorio = new File(configuracion.getGuardarDireccionPrimaria());
            File archivo = new File(directorio.getAbsolutePath() + "/error.rastro");
            FileOutputStream rastro = null;
            try {
                rastro = new FileOutputStream(archivo);
                if (ex.toString().indexOf("java.lang.OutOfMemoryError") >= 0) {
                    rastro.write(1);
                } else {
                    rastro.write(0);
                }
            } finally {
                try {
                    rastro.close();
                } catch (Exception e) {
                }
            }
            preferencias.limpiar(true);
        } catch (Throwable ignore) {
            iniciar.e(this, ignore);
        } finally {
            try {
                controlador.detenerCamara();
            } catch (Throwable e) {
            }
            defaultUEH.uncaughtException(hilo, ex);
        }
    }

    public void enviarEmail(File file) {
        BufferedReader buffleer = null;
        try {
            buffleer = new BufferedReader(new FileReader(file));
            String linea;
            StringBuffer report = new StringBuffer();
            while ((linea = buffleer.readLine()) != null) {
                report.append(linea);
                report.append("\n");
            }

            Intent enviarIntento = new Intent(Intent.ACTION_SEND);
            enviarIntento.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            String tema = "[Spy Camera OS] Error reportado";
            enviarIntento.putExtra(Intent.EXTRA_EMAIL,
                    new String[]{"jwork.spy.camera.os@gmail.com"});
            enviarIntento.putExtra(Intent.EXTRA_TEXT, report.toString());
            enviarIntento.putExtra(Intent.EXTRA_SUBJECT, tema);

            File iniciarArchivo = new File(Configuracion_Utilidad.getInstancia(null).getGuardarDireccionPrimaria() + File.separator + "loggingError.txt");

            if (iniciarArchivo.exists()) {
                enviarIntento.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(iniciarArchivo));
            }

            enviarIntento.setType("mensaje/rfc822");

            actividad.startActivity(Intent.createChooser(enviarIntento, "Email:"));

        } catch (Exception e) {
            Log.v("enviarEmail", e.toString());
        } finally {
            if (buffleer != null) {
                try {
                    buffleer.close();
                } catch (IOException e) {
                }
            }
        }
    }

    private File crearArchivoError(Throwable ex) {
        Main_Controlador controlador = fabrica.getMainControlador(null, null);
        Configuracion_Utilidad configuracion = Configuracion_Utilidad.getInstancia(null);
        String informacion = controlador.reporteError();

        String report = Utilidades.crearReporteError(ex, actividad, informacion);
        iniciar.e(this, "report " + report);
        File archivo = null;
        FileOutputStream trace = null;
        try {
            File directorio = new File(configuracion.getGuardarDireccionPrimaria());
            if (!directorio.exists()) {
                directorio.mkdir();
            }
            archivo = new File(directorio.getAbsolutePath() + "/stack.trace");
            trace = new FileOutputStream(archivo);
            trace.write(report.getBytes());
        } catch (IOException ioe) {
            iniciar.w(this, ioe);
        } finally {
            if (trace != null) {
                try {
                    trace.close();
                } catch (IOException e) {
                }
            }
        }
        return archivo;
    }

}
