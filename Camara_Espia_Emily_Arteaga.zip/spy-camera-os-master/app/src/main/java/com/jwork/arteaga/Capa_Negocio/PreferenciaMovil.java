
package com.jwork.arteaga.Capa_Negocio;

import android.app.Activity;
import android.content.Context;
import android.preference.Preference;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.google.ads.AdRequest;
import com.google.ads.AdSize;
import com.google.ads.AdView;

public class PreferenciaMovil extends Preference {

    public PreferenciaMovil(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public PreferenciaMovil(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public PreferenciaMovil(Context context) {
        super(context);
    }

    @Override
    protected View onCreateView(ViewGroup parent) {
        //esto creará la disposición lineal definida en ads_layout.xml
        View vista = super.onCreateView(parent);

        // el contexto es una PreferenceActivity
        Activity actividad = (Activity) getContext();

        // Crear el adView
        AdView adView = new AdView(actividad, AdSize.BANNER, "a1515a1ffdbf894");

        ((LinearLayout) vista).addView(adView);

        //Iniciar una solicitud genérica para cargarlo con un anuncio
        AdRequest requerimientos = new AdRequest();
        adView.loadAd(requerimientos);

        return vista;
    }
}