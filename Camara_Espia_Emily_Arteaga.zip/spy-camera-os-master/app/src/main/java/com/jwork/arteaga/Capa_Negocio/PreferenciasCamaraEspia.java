
package com.jwork.arteaga.Capa_Negocio;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.media.CamcorderProfile;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.OnScanCompletedListener;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceClickListener;
import android.preference.PreferenceActivity;
import android.util.Log;
import android.widget.Toast;

import com.jwork.arteaga.Capa_Datos.UtilidadInicio;
import com.jwork.arteaga.Capa_Datos.Utilidades;
import com.jwork.arteaga.R;

import java.io.File;
import java.io.IOException;
import java.util.Locale;

public class PreferenciasCamaraEspia extends PreferenceActivity implements OnSharedPreferenceChangeListener, OnPreferenceClickListener {

    private static final String ETIQUETA = PreferenciasCamaraEspia.class.getSimpleName();
    private String[][] tamanios;
    private Configuracion_Utilidad configuracion;
    private Preference feedbackReproduccion;
    private Preference feedbackEmail;
    private Preference acercaCodigoFuente;
    private Preference acercaCambios;
    private Preference CambioGeneralCarpetaEscondida;
    private Preference soporteDonaciones;
    private Preference iniciarModoNegro;
    private Preference compartir;
    private UtilidadInicio iniciar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.setting);
        iniciar = UtilidadInicio.getInstancia();

        configuracion = Configuracion_Utilidad.getInstancia(this);
        if (configuracion.getListaCalidadVideo(0) == null) {
            iniciar.w(this, "video quality empty, recreate configuracion");
            configuracion = Configuracion_Utilidad.createInstance(this);
        }

        configuracion.registrarEnCambioCompartido(this);
        iniciar.v(this, "onCreate()");

        int cameraNumber = getIntent().getIntExtra("cameraNumber", 1);
        String[] camaraPreferenciasOpciones = new String[cameraNumber];
        String[] camaraPreferenciaValores = new String[cameraNumber];
        String[] camaraOpciones = getResources().getStringArray(R.array.cameraOptions);
        String[] camaraValores = getResources().getStringArray(R.array.cameraValues);
        for (int i = 0; i < cameraNumber; i++) {
            camaraPreferenciasOpciones[i] = camaraOpciones[i];
            camaraPreferenciaValores[i] = camaraValores[i];
        }
        ListPreference listaPreferenciasCamara = (ListPreference) findPreference("cameraId");
        listaPreferenciasCamara.setEntries(camaraPreferenciasOpciones);
        listaPreferenciasCamara.setEntryValues(camaraPreferenciaValores);

        tamanios = new String[cameraNumber][];
        tamanios[0] = getIntent().getStringArrayExtra("cameraPreviewSizes0");
        if (tamanios.length > 1) {
            tamanios[1] = getIntent().getStringArrayExtra("cameraPreviewSizes1");
        }

        for (int id = 0; id < tamanios.length; id++) {
            ListPreference listaCategoriaPreferencia = (ListPreference) findPreference(Configuracion_Utilidad.PREFERENCIA_TAMANIO_IMAGEN + id);
            if (listaCategoriaPreferencia != null && tamanios[id] != null) {
                CharSequence entradas[] = new String[tamanios[id].length];
                CharSequence entradasValores[] = new String[tamanios[id].length];
                int i = 0;
                for (String tamanio : tamanios[id]) {
                    if (tamanio.endsWith("*")) {
                        entradas[i] = "[High] " + tamanio;
                    } else {
                        entradas[i] = "[Low] " + tamanio;
                    }
                    entradasValores[i] = tamanio;
                    i++;
                }
                listaCategoriaPreferencia.setEntries(entradas);
                listaCategoriaPreferencia.setEntryValues(entradasValores);
            }
        }

        if (tamanios.length == 1) {
            ListPreference listaPreferenciaCategoria = (ListPreference) findPreference(Configuracion_Utilidad.PREFERENCIA_TAMANIO_1);
            listaPreferenciaCategoria.setEnabled(false);
        }

        for (int id = 0; id < tamanios.length; id++) {
            ListPreference listaCalidadVideo = (ListPreference) findPreference(Configuracion_Utilidad.PREFERENCIA_VIDEO_CALIDAD + id);
            try {
                String[] ingresarValores = configuracion.getListaCalidadVideo(id).split("#");
                String[] entradas = new String[ingresarValores.length];

                for (int i = 0; i < ingresarValores.length; i++) {
                    if (ingresarValores[i].equals("" + CamcorderProfile.QUALITY_LOW)) {
                        entradas[i] = "Mas baja";
                    } else if (ingresarValores[i].equals("" + CamcorderProfile.QUALITY_QCIF)) {
                        entradas[i] = "QCIF (176x144)";
                    } else if (ingresarValores[i].equals("" + CamcorderProfile.QUALITY_QVGA)) {
                        entradas[i] = "QVGA (320x240)";
                    } else if (ingresarValores[i].equals("" + CamcorderProfile.QUALITY_CIF)) {
                        entradas[i] = "CIF (352x288)";
                    } else if (ingresarValores[i].equals("" + CamcorderProfile.QUALITY_480P)) {
                        entradas[i] = "480p (720x480)";
                    } else if (ingresarValores[i].equals("" + CamcorderProfile.QUALITY_720P)) {
                        entradas[i] = "720p (1280x720)";
                    } else if (ingresarValores[i].equals("" + CamcorderProfile.QUALITY_1080P)) {
                        entradas[i] = "1080p (1920x1080)";
                    } else if (ingresarValores[i].equals("" + CamcorderProfile.QUALITY_HIGH)) {
                        entradas[i] = "Mas alta";
                    } else {
                        entradas[i] = "Desconocido : " + ingresarValores[i];
                    }
                }
                listaCalidadVideo.setEntries(entradas);
                listaCalidadVideo.setEntryValues(ingresarValores);
            } catch (RuntimeException re) {
                iniciar.e(this, re);
                Toast.makeText(this, "Error al Cargar la Calidad VIdeo", Toast.LENGTH_SHORT).show();
                listaCalidadVideo.setEnabled(false);
            }
        }

        if (tamanios.length == 1) {
            ListPreference listPrefereciasCategoria = (ListPreference) findPreference(Configuracion_Utilidad.PREFERENCIA_CALIDAD_1);
            listPrefereciasCategoria.setEnabled(false);
        }

        ListPreference savingPath = (ListPreference) findPreference(Configuracion_Utilidad.GUARDAR_DIRECTORIO);
        String externa = configuracion.getGuardarDireccionExterna();
        String[] ingresarValores = new String[externa == null ? 1 : 2];
        ingresarValores[0] = configuracion.getGuardarDireccionPrimaria();
        if (externa != null) {
            ingresarValores[1] = configuracion.getGuardarDireccionExterna();
            savingPath.setEntries(R.array.savingPathOptions);
        } else {
            savingPath.setEntries(new String[]{"Phone"});
        }
        savingPath.setEntryValues(ingresarValores);
        savingPath.setDefaultValue(ingresarValores[0]);

        feedbackReproduccion = (Preference) findPreference("feedbackReproduccion");
        feedbackReproduccion.setOnPreferenceClickListener(this);
        feedbackEmail = (Preference) findPreference("feedbackEmail");
        feedbackEmail.setOnPreferenceClickListener(this);
        acercaCodigoFuente = (Preference) findPreference("acercaCodigoFuente");
        acercaCodigoFuente.setOnPreferenceClickListener(this);
        acercaCambios = (Preference) findPreference("acercaCambios");
        acercaCambios.setOnPreferenceClickListener(this);
        CambioGeneralCarpetaEscondida = (Preference) findPreference("hideFolder");
        CambioGeneralCarpetaEscondida.setOnPreferenceClickListener(this);
        compartir = (Preference) findPreference("Compartir");
        compartir.setOnPreferenceClickListener(this);
        soporteDonaciones = (Preference) findPreference("soporteDonaciones");
        soporteDonaciones.setOnPreferenceClickListener(this);
        iniciarModoNegro = (Preference) findPreference("iniciarModoNegro");
        iniciarModoNegro.setOnPreferenceClickListener(this);
        ((Preference) findPreference("autoEmailGmailCreate")).setOnPreferenceClickListener(this);
        ((Preference) findPreference(Configuracion_Utilidad.PREFERENCIA_ROTAR_IMAGEN)).setOnPreferenceClickListener(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        configuracion.dejarRegistrarEnCambioCompartido(this);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences,
                                          String llave) {
        iniciar.d(this, "enCambiodePreferencia(llave:" + llave + ")");
        if (llave.equals(Configuracion_Utilidad.CAMARA_ID)) {
            int activarCamara = configuracion.getCamaraCorriente();
            if (tamanios != null && tamanios[activarCamara] != null) {
                ListPreference listaPreferenciaCategoria = (ListPreference) findPreference("imageSize");
                if (listaPreferenciaCategoria != null) {
                    CharSequence entradas[] = new String[tamanios[activarCamara].length];
                    CharSequence valoresEntrada[] = new String[tamanios[activarCamara].length];
                    int i = 0;
                    for (String tamanio : tamanios[activarCamara]) {
                        entradas[i] = tamanio;
                        valoresEntrada[i] = tamanio;
                        i++;
                    }
                    listaPreferenciaCategoria.setEntries(entradas);
                    listaPreferenciaCategoria.setEntryValues(valoresEntrada);
                }
            }
        } else if (llave.toLowerCase(Locale.getDefault()).contains(Configuracion_Utilidad.PREFERENCIA_TAMANIO_IMAGEN.toLowerCase(Locale.getDefault()))) {
            String size = sharedPreferences.getString(llave, "");
            if (size.endsWith("*")) {
                final AlertDialog dialogoAlerta = new AlertDialog.Builder(this).create();
                dialogoAlerta.setMessage(getString(R.string.warning_image_resolution));
                dialogoAlerta.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialogoAlerta.dismiss();
                    }
                });
                dialogoAlerta.show();
            }
        } else if (llave.toLowerCase(Locale.getDefault()).contains(Configuracion_Utilidad.GUARDAR_DIRECTORIO.toLowerCase(Locale.getDefault()))) {
            File directory = new File(configuracion.getGuardarDireccion());
            if (!directory.exists()) {
                directory.mkdir();
            }
            if (!directory.exists() || !directory.canWrite()) {
                final AlertDialog ad = new AlertDialog.Builder(this).create();
                ad.setMessage("Unable to write in directory : " + configuracion.getGuardarDireccion() + "\nCanceling changes");
                ad.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ad.dismiss();
                    }
                });
                ad.show();
                configuracion.setGuardarDireccion(configuracion.getGuardarDireccionPrimaria());
            }
        } else if (llave.toLowerCase(Locale.getDefault()).contains(Configuracion_Utilidad.INICIAR_MODO_NEGRO.toLowerCase(Locale.getDefault()))) {
            boolean blackMode = sharedPreferences.getBoolean(llave, false);
            if (blackMode) {
                final AlertDialog dialogoAlerta = new AlertDialog.Builder(this).create();
                dialogoAlerta.setMessage(getString(R.string.hint_blackmode));
                dialogoAlerta.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialogoAlerta.dismiss();
                    }
                });
                dialogoAlerta.show();
            }
        } else if (llave.toLowerCase(Locale.getDefault()).contains(Configuracion_Utilidad.PREFERENCIA_ROTAR_IMAGEN.toLowerCase(Locale.getDefault()))) {
            int rotation = configuracion.getRotacionImagen();
            if (rotation != 0) {
                final AlertDialog ad = new AlertDialog.Builder(this).create();
                ad.setMessage(getString(R.string.warning_image_rotation));
                ad.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ad.dismiss();
                    }
                });
                ad.show();
            }
        } else if (llave.toLowerCase(Locale.getDefault()).contains(Configuracion_Utilidad.PREFERENCIA_EMAIL_HABILITADO.toLowerCase(Locale.getDefault()))) {
            if (sharedPreferences.getBoolean(Configuracion_Utilidad.PREFERENCIA_EMAIL_HABILITADO, false)) {
                final AlertDialog ad = new AlertDialog.Builder(this).create();
                ad.setMessage(getString(R.string.warning_enable_auto_email));
                ad.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ad.dismiss();
                    }
                });
                ad.show();
            }
        }
    }

    @Override
    public boolean onPreferenceClick(Preference preferencia) {
        if (preferencia == feedbackReproduccion) {
            Uri uri = Uri.parse("mercado://details?id=" + getPackageName());
            Intent miAppParaElMercado = new Intent(Intent.ACTION_VIEW, uri);
            try {
                startActivity(miAppParaElMercado);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "Fallo en encontrar el mercado", Toast.LENGTH_LONG).show();
            }
            return true;
        } else if (preferencia == feedbackEmail) {
            Intent sendIntent = new Intent(Intent.ACTION_SEND);
            sendIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            String subject = "[Spy Camara OS] Feedback";
            sendIntent.putExtra(Intent.EXTRA_EMAIL,
                    new String[]{"jwork.spy.camera.os@gmail.com"});
            sendIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
            sendIntent.putExtra(Intent.EXTRA_TEXT, "\n-------------------------------\n" + Utilidades.getInformacionTelefono(this));
            UtilidadInicio log = UtilidadInicio.getInstancia();
            log.liberandoIngreso(this);
            File logFile = new File(configuracion.getGuardarDireccionPrimaria() + File.separator + "logging.txt");
            if (configuracion.getIngresando() && logFile.exists()) {
                sendIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(logFile));
            }

            sendIntent.setType("mensaje/rfc822");
            startActivity(Intent.createChooser(sendIntent, "Email:"));
            return true;
        } else if (preferencia == acercaCodigoFuente) {
            Intent i = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("spycamera.ucuenca.emily.arteaga"));
            startActivity(i);
            return true;
        } else if (preferencia == soporteDonaciones) {
            Utilidades.abrirDonaciones(this);
            return true;
        } else if (preferencia == compartir) {
            Utilidades.Compartir(this);
            return true;
        } else if (preferencia == acercaCambios) {
            Utilidades.mostrarCambiarLogo(false, this, false);
            return true;
        } else if (preferencia == CambioGeneralCarpetaEscondida) {
            File file = new File(configuracion.getGuardarDireccion() + "/.nomedia");
            if (configuracion.estaOcultaCarpeta()) {
                if (!file.exists()) {
                    try {
                        System.out.println("Crear:" + file.createNewFile());
                    } catch (IOException e) {
                        Log.w(ETIQUETA, e);
                    }
                }
            } else {
                if (file.exists()) {
                    System.out.println("Del:" + file.delete());
                }
            }
            iniciar.i(this, "Exploracion de medios");
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_MOUNTED, Uri.parse("archivo://" + Environment.getExternalStorageDirectory())));
            MediaScannerConnection.scanFile(this, new String[]{configuracion.getGuardarDireccionExterna(), configuracion.getGuardarDireccionPrimaria()}, null, new OnScanCompletedListener() {

                @Override
                public void onScanCompleted(String path, Uri uri) {
                    iniciar.d(this, "enEscanerCOmpleto(direccion:" + path + "|url:" + uri + ")");
                }
            });
            return true;
        } else if (preferencia.getKey().equals("autoGmailCreado")) {
            Uri uri = Uri.parse("https://accounts.google.com/SignUp");
            Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
            try {
                startActivity(myAppLinkToMarket);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "Fallo en buscar aplicacion", Toast.LENGTH_LONG).show();
            }
            return true;
        }
        return false;
    }
}
