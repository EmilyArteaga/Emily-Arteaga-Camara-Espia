
package com.jwork.arteaga;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.YuvImage;
import android.hardware.Camera;
import android.hardware.Camera.AutoFocusCallback;
import android.hardware.Camera.Face;
import android.hardware.Camera.FaceDetectionListener;
import android.hardware.Camera.OnZoomChangeListener;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.PreviewCallback;
import android.hardware.Camera.ShutterCallback;
import android.hardware.Camera.Size;
import android.media.AudioManager;
import android.media.CamcorderProfile;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;

import com.jwork.arteaga.Capa_Negocio.Llamado_Camara;
import com.jwork.arteaga.Capa_Negocio.PreferenciasCamaraEspia;
import com.jwork.arteaga.Capa_Presentacion.ProcesosDetenidos;
import com.jwork.arteaga.Capa_Negocio.Configuracion_Utilidad;
import com.jwork.arteaga.Capa_Negocio.ManejoColisiones;
import com.jwork.arteaga.Capa_Datos.EnvioMensaje;
import com.jwork.arteaga.Capa_Datos.UtilidadInicio;
import com.jwork.arteaga.Capa_Datos.Utilidades;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

import javax.mail.AuthenticationFailedException;

public class Main_Controlador implements OnZoomChangeListener, PreviewCallback, AutoFocusCallback
        , PictureCallback, ShutterCallback, Serializable {

    public static final int ESTADO_ID = 0;
    private int estado = ESTADO_ID;
    public static final int ESTADO_IMAGEN_UNICA = 1;
    public static final int ESTADO_AUTO_IMAGEN = 2;
    public static final int ESTADO_IMAGEN_CARA = 3;
    public static final int ESTADO_VIDEO_GRABADO = 4;
    public static final int QUE_INICIAR_AUTO_TOMADO = 1;
    public static final int QUE_DETENER_AUTO_TOMADO = 2;
    public static final int QUE_CONTINUAR_AUTO_TOMADO = 3;
    public static final int QUE_INICIAR_TOMADO_CARA = 4;
    public static final int QUE_DETENER_TOMDO_CARA = 5;
    public static final int QUE_INICIAR_VIDEO = 6;
    public static final int QUE_DETENER_VIDEO = 7;

    private static final long serialVersionId = 4120558915025481125L;
    private final static SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd_HHmmssSSS", Locale.getDefault());
    private UtilidadInicio iniciar;
    private Activity actividad;
    private Handler controlador;
    private Camera camara;
    private SurfaceHolder shAvance;
    private Configuracion_Utilidad configuracion;

    private boolean estaControlListo = false;
    private boolean estaCamaraConfigurada = false;
    private boolean estaEncendidoAutoEnfocado = false;
    private boolean estaPantallaNegra = false;
    private int camaraId;
    private long ultimaCaptura = 0;
    private long ultimoAutoEnfocado = 0;
    private long avgTiempoAutoEnfocado = -1;
    private String[][] camaraTamanios;
    private String[][] calidadesVideo;
    private boolean reporteColision = false;
    private int zoomCorriente = 0;
    private int defaultOrientacion;
    private int corrienteCamcorderProfileId;
    private Parameters parametrosCamara;
    private boolean estaEnLaMasAltaResolucion;
    private byte[] chasquido;
    private Camera.Size Tamanio;
    private Camera.Size mayorTamanio;
    private Camera.Size capturarTamanio;
    private Camera.Size capturarMayorTamanoi;
    private MediaRecorder grabar;
    private CamcorderProfile perfilCamaraCorriente = null;
    private boolean correrZoom;
    private boolean seHaDesplegadoZoom = false;
    private int tempTamanio = 1;

    private boolean estaTomandoFotos = false;
    private boolean isUIDisplayed = false;

    private int modo;

    private SurfaceView vistaSuperficie;

    private Handler controladorCamra = new MainControllerHandler(this);
    private boolean accionAjuste = false;

    ;
    private AutoShootLocalAsync autoTareaImagen;
    private GMailSenderTask tareaMail = null;
    private ArrayList<File> imagenesParaMail = new ArrayList<File>();

    public Main_Controlador(Activity actividad, Handler controlador) {
        this.actividad = actividad;
        this.controlador = controlador;
        this.iniciar = UtilidadInicio.getInstancia();
        this.configuracion = Configuracion_Utilidad.getInstancia(actividad);
    }

    public void iniciarDatos() {
        iniciar.v(this, "iniciandoData()");

        reporteColision = chequearColisionAnterior();
        estaPantallaNegra = false;

        if (!reporteColision && Llamado_Camara.estado == Llamado_Camara.QUE_DETIENE) {
            Message mensaje = new Message();
            mensaje.what = Main_Principal.WHAT_SET_PREVIEW_IMAGE;
            mensaje.arg1 = configuracion.getAvanceTamanioImagen();
            mensaje.arg2 = mensaje.arg1;
            controlador.sendMessage(mensaje);

            if (!Utilidades.mostrarCambiarLogo(true, actividad, (camara == null)) && configuracion.estaEnModoNegro()) {
                cambiarAPantallaNegra();
            }
        }

    }

    @SuppressLint("NuevoApi")
    public void startCamera(SurfaceView vistaSupericie) {
        iniciar.v(this, "IniciandoCamara()");
        this.vistaSuperficie = vistaSupericie;
        if (!reporteColision) {
            camaraId = 0;
            try {
                if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.FROYO) {
                    camara = Camera.open();
                    camaraTamanios = new String[1][];
                    calidadesVideo = new String[1][];
                    Message msg = new Message();
                    msg.what = Main_Principal.WHAT_HIDE_COMPONENT;
                    msg.arg1 = R.id.btnSwitchCam;
                    controlador.sendMessage(msg);
                } else {
                    int total = Camera.getNumberOfCameras();
                    if (total > 2) {
                        total = 2;
                    } else if (total == 1) {
                        Message msg = new Message();
                        msg.what = Main_Principal.WHAT_HIDE_COMPONENT;
                        msg.arg1 = R.id.btnSwitchCam;
                        controlador.sendMessage(msg);
                    }

                    camaraTamanios = new String[total][];
                    calidadesVideo = new String[total][];

                    camaraId = configuracion.getCamaraCorriente();

                    if (total > 1) {
                        int anotherCameraId = (camaraId == 0) ? 1 : 0;
                        String temp = configuracion.getTamaniosPrevios(anotherCameraId);
                        if (temp == null) {
                            camara = Camera.open(anotherCameraId);
                            StringBuffer dato = new StringBuffer();
                            camaraTamanios[anotherCameraId] = Utilidades.tamanioCamaraSoportado(camara.getParameters(), dato);
                            camara.release();
                            configuracion.setCamaraTamaniosPrevios(anotherCameraId, dato.toString());
                        } else {
                            camaraTamanios[anotherCameraId] = temp.split("#");
                        }
                        temp = configuracion.getListaCalidadVideo(anotherCameraId);
                        if (temp == null) {
                            StringBuffer dato = new StringBuffer();
                            calidadesVideo[anotherCameraId] = Utilidades.ordenSoporteCamara(anotherCameraId, dato);
                            configuracion.setListaCalidadVideo(anotherCameraId, dato.toString());
                        } else {
                            calidadesVideo[anotherCameraId] = temp.split("#");
                        }
                    }
                    camara = Camera.open(camaraId);
                }
                parametrosCamara = camara.getParameters();

                String temp = configuracion.getTamaniosPrevios(camaraId);
                if (temp == null) {
                    // Obtener tamanios anteriores
                    StringBuffer dato = new StringBuffer();
                    camaraTamanios[camaraId] = Utilidades.tamanioCamaraSoportado(camara.getParameters(), dato);
                    configuracion.setCamaraTamaniosPrevios(camaraId, dato.toString());
                } else {
                    camaraTamanios[camaraId] = temp.split("#");
                }
                temp = configuracion.getListaCalidadVideo(camaraId);
                if (temp == null) {
                    StringBuffer data = new StringBuffer();
                    calidadesVideo[camaraId] = Utilidades.ordenSoporteCamara(camaraId, data);
                    configuracion.setListaCalidadVideo(camaraId, data.toString());
                } else {
                    calidadesVideo[camaraId] = temp.split("#");
                }


                String configuracionTamanio = configuracion.getTamanioImagenCapturada(camaraId);
                if (configuracionTamanio != null) {
                    if (configuracionTamanio.endsWith("*")) {
                        estaEnLaMasAltaResolucion = true;
                    } else {
                        estaEnLaMasAltaResolucion = false;
                    }
                } else {
//					if (!configuracion.isHaveOutOfMemoryIssue()) {
                    estaEnLaMasAltaResolucion = false;
//					} else {
//						estaEnLaMasAltaResolucion = true;
//					}
                }
                //Analizar avance del mismo tamaño / captura
                int LamasAlta = 0;
                int capturaAlta = 0;
                this.Tamanio = null;
                this.mayorTamanio = null;
                this.capturarTamanio = null;
                this.capturarMayorTamanoi = null;
                for (String TamanioAvance : camaraTamanios[camaraId]) {
                    int w = 0;
                    int h = 0;
                    String tamanio = null;
                    if (TamanioAvance.endsWith("*")) {
                        tamanio = TamanioAvance.substring(0, TamanioAvance.length() - 1);
                    } else {
                        tamanio = TamanioAvance;
                    }
                    String[] temp2 = tamanio.split("x");
                    try {
                        w = Integer.parseInt(temp2[0]);
                    } catch (NumberFormatException e) {
                    }
                    try {
                        h = Integer.parseInt(temp2[1]);
                    } catch (NumberFormatException e) {
                    }

                    if (TamanioAvance.endsWith("*") && (capturaAlta < w * h)) {
                        capturarMayorTamanoi = camara.new Size(w, h);
                        capturaAlta = w * h;
                    } else if (!TamanioAvance.endsWith("*") && (LamasAlta < w * h)) {
                        mayorTamanio = camara.new Size(w, h);
                        LamasAlta = w * h;
                    }

                    if (configuracionTamanio != null && TamanioAvance.equals(configuracionTamanio)) {
                        if (estaEnLaMasAltaResolucion) {
                            this.capturarTamanio = camara.new Size(w, h);
                            this.Tamanio = null;
                        } else {
                            this.Tamanio = camara.new Size(w, h);
                            this.capturarTamanio = null;
                        }
                    }
                }
                if (Tamanio == null) {
                    Tamanio = mayorTamanio;
                }

                if (estaEnLaMasAltaResolucion && this.capturarTamanio == null) {
                    this.capturarTamanio = capturarMayorTamanoi;
                }

                if (estaEnLaMasAltaResolucion) {
                    configuracion.setTamanioImagenCapturada(camaraId, capturarTamanio.width + "x" + capturarTamanio.height + "*");
                } else {
                    configuracion.setTamanioImagenCapturada(camaraId, Tamanio.width + "x" + Tamanio.height);
                }

                refreshImagenTamanio();

                if (shAvance != null) {
                    try {
                        camara.setPreviewDisplay(shAvance);
                    } catch (IOException e) {
                        iniciar.w(this, e);
                    }
                }

                //Calidad del Video
                int perfilVideo = configuracion.getCalidadVideoGrabado(camaraId);
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
                        iniciar.d(this, "Perfil de Video Cámara Actual : " + perfilVideo);
                        perfilCamaraCorriente = CamcorderProfile.get(camaraId, perfilVideo);
                        corrienteCamcorderProfileId = perfilVideo;
                    }
                } catch (IllegalArgumentException e) {
                    iniciar.d(this, "\n" + "Falla en conseguir perfil video cámara, cambiar el uso : " + CamcorderProfile.QUALITY_LOW);
                    try {
                        perfilCamaraCorriente = CamcorderProfile.get(camaraId, CamcorderProfile.QUALITY_LOW);
                        corrienteCamcorderProfileId = CamcorderProfile.QUALITY_LOW;
                    } catch (IllegalArgumentException e2) {
                        iniciar.d(this, "\n" + "Siguen sin conseguir el perfil videocámara, la desactivación de la grabación de vídeo");
                        showToast(true, Toast.LENGTH_LONG, "\n" + "No se puede inicializar la grabación de vídeo, deshabilitando la función");
                        Message msg = new Message();
                        msg.what = Main_Principal.WHAT_DISABLE_COMPONENT;
                        msg.arg1 = R.id.btnVideo;
                        controlador.sendMessage(msg);
                    }
                }
            } catch (RuntimeException re) {
                iniciar.w(this, re);
                reporteColision = true;
                if (re.getMessage().toLowerCase(Locale.getDefault()).contains("conectando")) {
                    configuracion.limpiar(false);
                    Message msg = new Message();
                    msg.what = Main_Principal.WHAT_SHOW_FAILED_PROCESS;
                    msg.obj = new ProcesosDetenidos(re
                            , "\n" + "No se pudo inicializar cámara. Por favor, intente reiniciar el teléfono manualmente y ejecutar la aplicación de nuevo."
                            , "Tras el reinicio sigue el error"
                            , "OK", true, null);
                    controlador.sendMessage(msg);
                } else if (re.getMessage().toLowerCase(Locale.getDefault()).contains("ConseguirParametros")) {
                    configuracion.limpiar(false);
                    Message msg = new Message();
                    msg.what = Main_Principal.WHAT_SHOW_FAILED_PROCESS;
                    msg.obj = new ProcesosDetenidos(re
                            , "\n" + "No se pudo obtener parámetros de la cámara. El envío de informe de errores le ayudará a corregir el problema"
                            , "Enviando Reporte"
                            , "Lo envié", true, null);
                    controlador.sendMessage(msg);
                } else {
                    throw re;
                }
            }

            if (estaCamaraConfigurada) {
                iniciarCamaraAvance(shAvance);
            } else if (estaControlListo) {
                configurarCamara(shAvance);
            }
        }
    }

    private void refreshImagenTamanio() {
        Message msg = new Message();
        msg.what = Main_Principal.WHAT_SET_PREVIEW_IMAGE;
        msg.arg1 = configuracion.getAvanceTamanioImagen();
        msg.arg2 = calcularAvancePeso(msg.arg1);
        if (msg.arg2 < 1) {
            msg.arg2 = 1;
        }
        controlador.sendMessage(msg);
    }

    private int calcularAvancePeso(int width) {
        int altura = -1;
        float proporcion = 1;
        if (estaEnLaMasAltaResolucion) {
            if (capturarTamanio == null) {
                iniciar.v(this, "\n" + "Vista previa de calcular Altura(width:" + width + "):" + width);
                return width;
            }
            proporcion = (float) capturarTamanio.height / (float) capturarTamanio.width;
        } else {
            if (Tamanio == null) {
                iniciar.v(this, "\n" + "Vista previa de calcular Altura(width:" + width + "):" + width);
                return width;
            }
            proporcion = (float) Tamanio.height / (float) Tamanio.width;
        }
        if (defaultOrientacion == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT || defaultOrientacion == ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT) {
            proporcion = 1 / proporcion;
        }
        altura = (int) (width * proporcion);
        iniciar.v(this, "Vista previa de calcular Altura(width:" + width + "):" + altura);
        return altura;
    }

    public void showToast(boolean forzar, int longitud, Object mensaje) {
        iniciar.v(this, "showToast(fuerza:" + forzar + "|logitud:" + longitud + "|mensaje:" + mensaje.toString() + ")");
        if (!isUIDisplayed || this.accionAjuste) {
            return;
        }
        Message mensajito = new Message();
        mensajito.what = Main_Principal.WHAT_SHOW_TOAST;
        mensajito.arg1 = forzar ? 1 : 0;
        mensajito.arg2 = longitud;
        mensajito.obj = mensaje;
        controlador.sendMessage(mensajito);
    }

    public synchronized void configurarCamara(SurfaceHolder holder) {
        iniciar.v(this, "ConfigurarCamara()");
        estaControlListo = true;
        shAvance = holder;
        if (camara == null) {
            iniciar.w(this, "Configurar Camara: la cámara es nula");
            return;
        }
        if (!estaCamaraConfigurada) {
            if (reporteColision) {
                return;
            }
            int rotacion = actividad.getWindowManager().getDefaultDisplay().getRotation();
            int grados = 0;

            DisplayMetrics metricas = new DisplayMetrics();
            actividad.getWindowManager().getDefaultDisplay().getMetrics(metricas);
            iniciar.v(this, "Pixeles de la Pantalla: " + metricas.widthPixels + "x" + metricas.heightPixels + "|Rotacion:" + rotacion);
            if (
                    ((rotacion == Surface.ROTATION_0 || rotacion == Surface.ROTATION_180) && metricas.widthPixels > metricas.heightPixels)
                            || ((rotacion == Surface.ROTATION_90 || rotacion == Surface.ROTATION_270) && metricas.widthPixels < metricas.heightPixels)
                    ) {
                rotacion += 1;
                if (rotacion > 3) {
                    rotacion = 0;
                }
            }
            switch (rotacion) {
                case Surface.ROTATION_0:
                    grados = 90;
                    defaultOrientacion = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
                    break;
                case Surface.ROTATION_90:
                    grados = 0;
                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.FROYO) {
                        defaultOrientacion = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
                    } else {
                        defaultOrientacion = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
                        actividad.setRequestedOrientation(defaultOrientacion);
                    }
                    break;
                case Surface.ROTATION_180:
                    grados = 270;
                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.FROYO) {
                        defaultOrientacion = ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT;
                    } else {
                        defaultOrientacion = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
                        actividad.setRequestedOrientation(defaultOrientacion);
                    }
                    break;
                case Surface.ROTATION_270:
                    grados = 180;
                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.FROYO) {
                        defaultOrientacion = ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE;
                    } else {
                        defaultOrientacion = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
                        actividad.setRequestedOrientation(defaultOrientacion);
                    }
                    break;
            }
            try {
                refreshImagenTamanio();
                iniciar.d(this, "Rotacion: " + rotacion + "|Oriencion:" + defaultOrientacion);
                camara.setDisplayOrientation(grados);
            } catch (RuntimeException re) {
                if (!configuracion.getBooleano(Configuracion_Utilidad.PREFERENCIA_REPORTE_ERRORES, false)) {
                    Message msg = new Message();
                    msg.what = Main_Principal.WHAT_SHOW_FAILED_PROCESS;
                    msg.obj = new ProcesosDetenidos(re
                            , "No se ha podido configurar la orientación de la vista previa. El envío de informe de errores le ayudará a corregir el problema."
                            , "Enviar Reporte"
                            , "OK", false, Configuracion_Utilidad.PREFERENCIA_REPORTE_ERRORES);
                    controlador.sendMessage(msg);
                } else {
                    showToast(true, Toast.LENGTH_LONG, "\n" + "No se ha podido configurar la orientación de la vista previa.");
                }
            }

            if (estaEnLaMasAltaResolucion) {
                parametrosCamara.setPictureSize(capturarTamanio.width, capturarTamanio.height);
                parametrosCamara.setPictureFormat(ImageFormat.JPEG);
                parametrosCamara.setRotation((camaraId == 0) ? 90 : 270);
            }
            iniciar.i(this, "\n" + "Tamaño de previsualización.anchura : " + Tamanio.width + "x" + Tamanio.height);
            parametrosCamara.setPreviewSize(Tamanio.width, Tamanio.height);
            parametrosCamara.setPreviewFormat(ImageFormat.NV21);
            if (parametrosCamara.getSupportedFocusModes().contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
                parametrosCamara.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
            } else {
                iniciar.d(this, "\n" + "No se admite el modo de enfoque automático : " + Arrays.toString(parametrosCamara.getSupportedFocusModes().toArray()));
            }
            camara.setParameters(parametrosCamara);

            iniciarCamaraAvance(shAvance);
            estaCamaraConfigurada = true;
        } else {
            iniciar.w(this, "Se ha configurado la Cámara");
            refreshImagenTamanio();
        }
    }

    public void iniciarCamaraAvance(SurfaceHolder controlador) {
        iniciar.v(this, "\n" + "iniciarpreviadelacámara()");
        try {
            iniciar.i(this, "\n" + "Iniciando previa de la cámara");
            camara.setZoomChangeListener(this);
            camara.setPreviewDisplay(controlador);
            camara.startPreview();
            camara.setPreviewCallback(this);
        } catch (IOException e) {
            showToast(true, Toast.LENGTH_LONG, "No se pudo inicializar previa de la cámara");
            iniciar.e(this, e);
        } catch (RuntimeException respuesta) {
            if (respuesta.getMessage().toLowerCase(Locale.getDefault()).contains("Iniciando Previa")) {
                configuracion.limpiar(false);
                Message mensaje = new Message();
                mensaje.what = Main_Principal.WHAT_SHOW_FAILED_PROCESS;
                mensaje.obj = new ProcesosDetenidos(respuesta
                        , "No se pudo inicializar previa de la cámara,Ayudame a Reportar Para Arreglarlo"
                        , "Enviar Reporte"
                        , "Lo envié", false, null);
                this.controlador.sendMessage(mensaje);
            } else {
                throw respuesta;
            }
        }
    }

    public void detenerCamara() {
        iniciar.v(this, "detenerCamara()");
        if (!reporteColision) {
            if (estado == ESTADO_VIDEO_GRABADO) {
                try {
                    detenerGrabacionVideo();
                } catch (RuntimeException e) {
                    iniciar.w(this, e);
                }
            }

            try {
                camara.cancelAutoFocus();
            } catch (Throwable e) {
            }
            try {
                camara.setPreviewCallback(null);
            } catch (Throwable e) {
            }
            try {
            } catch (Throwable e) {
                iniciar.w(this, e);
            }
            estaCamaraConfigurada = false;
            setEstado(ESTADO_ID);
        }
    }

    private void detenerGrabacionVideo() {
        iniciar.v(this, "DetenerGrabacionVideo()|estado:" + estado);
        if (grabar != null) {
            showToast(false, Toast.LENGTH_SHORT, R.string.message_stopVideo);

            setEstado(ESTADO_ID);
            try {
                grabar.stop();
                grabar.reset();
                grabar.release();
                camara.lock();
            } catch (RuntimeException re) {
                showToast(false, Toast.LENGTH_SHORT, "\n" + "Aparecio un error en detener la grabación de vídeo");
                iniciar.w(this, re);
            }
            try {
                camara.reconnect();
            } catch (IOException e) {
                iniciar.w(this, e);
            }
        }
    }

    public void cambiarCamara() {
        if (camaraTamanios == null || camaraTamanios.length <= 1) {
            return;
        }
        int camaraActivada = configuracion.getCamaraCorriente();
        if (camaraActivada == 0) {
            camaraActivada = 1;
        } else {
            camaraActivada = 0;
        }
        configuracion.setCamaraCorriente(camaraActivada);
        detenerCamara();
        startCamera(vistaSuperficie);
    }

    public void cambiarAPantallaNegra() {
        iniciar.v(this, "cambiarAPantallaNegra()|estaPantallaNegra:" + estaPantallaNegra);
        if (!estaPantallaNegra) {
            Message mensaje = new Message();
            mensaje.what = Main_Principal.WHAT_SHOW_COMPONENT;
            mensaje.arg1 = R.id.blackLayout;
            controlador.sendMessage(mensaje);

            showToast(true, Toast.LENGTH_SHORT, actividad.getString(R.string.hint_blackmode));

            tempTamanio = configuracion.getAvanceTamanioImagen();
            configuracion.setAvanceTamanioImagen(1);
            refreshImagenTamanio();
        } else {
            Message mensaje = new Message();
            mensaje.what = Main_Principal.WHAT_HIDE_COMPONENT;
            mensaje.arg1 = R.id.blackLayout;
            controlador.sendMessage(mensaje);
            configuracion.setAvanceTamanioImagen(tempTamanio);
            refreshImagenTamanio();
        }
        estaPantallaNegra = !estaPantallaNegra;
    }

    public void capturaImagen() {
        iniciar.v(this, "capturarImagen()");
        if (estado == ESTADO_ID) {
            setEstado(ESTADO_IMAGEN_UNICA);
            IniciarAutoEnfocado();
        }
    }

    private void IniciarAutoEnfocado() {
        iniciar.v(this, "IniciarAutoEnfocado()");
        if (estaCamaraConfigurada) {
            ultimoAutoEnfocado = System.currentTimeMillis();
            if (configuracion.getUsarAutoEnfocado()) {
                try {
                    iniciar.d(this, "\n" + "modo de enfoque automático actual: " + parametrosCamara.getFocusMode());
                    if (!estaEncendidoAutoEnfocado) {
                        estaEncendidoAutoEnfocado = true;
                        camara.autoFocus(this);
                    } else {
                        iniciar.w(this, "\n" + "saltarse el enfoque automático, aún en medio de enfoque automático");
                    }
                } catch (RuntimeException re) {
                    iniciar.e(this, re);
                    onAutoFocus(true, camara);
                }
            } else {
                iniciar.d(this, "\n" +
                        "Cancelación de enfoque automático, llamando directamente en Auto Enfocado");
                onAutoFocus(true, camara);
            }
        } else {
            iniciar.w(this, "\n" +
                    "La cámara no está configurado, puede no iniciarAutoEnfocado");
        }
    }

    public void CapturaautomticaImagen() {
        iniciar.v(this, "\n" + "CapturaautomticaImagen()");
        if (estado == ESTADO_ID) {
            if (configuracion.getDeshabilitarSevicioBackground()) {
                autoCapturadeImagenIniciar();
                autoTareaCapturadeImagenIniciada();
            } else {
                Intent intento = new Intent(actividad, Llamado_Camara.class);
                Messenger mensajeria = new Messenger(controladorCamra);
                intento.putExtra(Llamado_Camara.EXTRA_MESSENGER, mensajeria);
                intento.putExtra(Llamado_Camara.EXTRA_ACTION, Llamado_Camara.QUE_INICIA_AUTOTOMADO);
                actividad.startService(intento);
            }
        } else if (estado == ESTADO_AUTO_IMAGEN) {
            if (configuracion.getDeshabilitarSevicioBackground()) {
                autoCapturadeImagenDetener();
                tareaAutoCapturaDeImagenDetener();
            } else {
                Intent intento = new Intent(actividad, Llamado_Camara.class);
                Messenger mensajeria = new Messenger(controladorCamra);
                intento.putExtra(Llamado_Camara.EXTRA_MESSENGER, mensajeria);
                intento.putExtra(Llamado_Camara.EXTRA_ACTION, Llamado_Camara.QUE_DETIENE);
                actividad.stopService(intento);
            }
        }
    }

    public void abrirAjustes() {
        if (estado == ESTADO_ID) {
            Intent intent = new Intent(actividad, PreferenciasCamaraEspia.class);

            if (camaraTamanios[0] != null) {
                intent.putExtra("TamanioPrevioCamara0", camaraTamanios[0]);
            }
            if (camaraTamanios.length > 1 && camaraTamanios[1] != null) {
                intent.putExtra("TamanioPrevioCamar1", camaraTamanios[1]);
            }
            intent.putExtra("NumeroCamara", camaraTamanios.length);
            actividad.startActivity(intent);
        } else {
            // si no está el botón es para minimizar
            if (!configuracion.estaExperimentalMinimizado()) {
                Message mensaje = new Message();
                mensaje.what = Main_Principal.WHAT_SHOW_MINIMIZE_EXPERIMENTAL_NOTICE;
                controlador.sendMessage(mensaje);
                configuracion.setExperimentalMinimizado();
                return;
            } else {
                actividad.finish();
            }
        }
    }

    public void autoCapuraCara() {
        iniciar.v(this, "CapturaAutomaticaCara()");
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
            showToast(true, Toast.LENGTH_SHORT, "Deteccion de la Cara es soportada solo para Android 4.0 en adelante");
            return;
        }
        if (camara == null) {
            showToast(true, Toast.LENGTH_SHORT, "\n" + "La cámara no está inicializado");
            return;
        }
        if (estado == ESTADO_ID) {
            if (configuracion.getDeshabilitarSevicioBackground()) {
                autoFaceCapturaImagenIniciada();
            } else {
                Intent intento = new Intent(actividad, Llamado_Camara.class);
                Messenger mensaje = new Messenger(controladorCamra);
                intento.putExtra(Llamado_Camara.EXTRA_MESSENGER, mensaje);
                intento.putExtra(Llamado_Camara.EXTRA_ACTION, Llamado_Camara.QUE_INICIA_TOMADO_CARA);
                actividad.startService(intento);
            }
        } else if (estado == ESTADO_IMAGEN_CARA) {
            if (configuracion.getDeshabilitarSevicioBackground()) {
                autoCapturaImagenDetenida();
            } else {
                Intent intento = new Intent(actividad, Llamado_Camara.class);
                Messenger mensaje = new Messenger(controladorCamra);
                intento.putExtra(Llamado_Camara.EXTRA_MESSENGER, mensaje);
                intento.putExtra(Llamado_Camara.EXTRA_ACTION, Llamado_Camara.QUE_DETIENE);
                actividad.stopService(intento);
            }
        }
    }

    public void grabandoVideo() {
        iniciar.v(this, "GragandoVideo()");
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.GINGERBREAD) {
            showToast(true, Toast.LENGTH_SHORT, "\n" + "La grabación de vídeo sólo es compatible con Android 2.3 en adelante");
            return;
        }
        if (!configuracion.estaNoticiaExperimentado()) {
            Message mensaje = new Message();
            mensaje.what = Main_Principal.WHAT_SHOW_VIDEO_RECORDING_EXPERIMENTAL_NOTICE;
            controlador.sendMessage(mensaje);
            configuracion.setNoticiaExperimental();
            return;
        }
        if (estado == ESTADO_ID) {
            if (configuracion.getDeshabilitarSevicioBackground()) {
                grabadoVideoIniciado();
            } else {
                Intent intento = new Intent(actividad, Llamado_Camara.class);
                Messenger mensaje = new Messenger(controladorCamra);
                intento.putExtra(Llamado_Camara.EXTRA_MESSENGER, mensaje);
                intento.putExtra(Llamado_Camara.EXTRA_ACTION, Llamado_Camara.QUE_INICIA_GRABACION_VIDEO);
                actividad.startService(intento);
            }
        } else {
            if (configuracion.getDeshabilitarSevicioBackground()) {
                grabajodeVideoDetener();
            } else {
                Intent intento = new Intent(actividad, Llamado_Camara.class);
                Messenger mensaje = new Messenger(controladorCamra);
                intento.putExtra(Llamado_Camara.EXTRA_MESSENGER, mensaje);
                intento.putExtra(Llamado_Camara.EXTRA_ACTION, Llamado_Camara.QUE_DETIENE);
                actividad.stopService(intento);
            }
        }

    }

    private void iniciarGrabadoVideo() {
        File directorio = new File(configuracion.getGuardarDireccion());
        if (!directorio.exists()) {
            directorio.mkdir();
        }
        String archivoSalida = null;
        try {
            try {
                camara.unlock();
            } catch (Throwable re) {
                iniciar.w(this, re);
            }
            grabar = new MediaRecorder();
            grabar.setCamera(camara);
            grabar.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);
            grabar.setVideoSource(MediaRecorder.VideoSource.CAMERA);

            grabar.setProfile(perfilCamaraCorriente);

            archivoSalida = directorio.getAbsolutePath() + "/VideoEspia_" + SDF.format(new Date()) + ".mp4";
            grabar.setOutputFile(archivoSalida);
            grabar.setPreviewDisplay(shAvance.getSurface());
            grabar.prepare();
            grabar.start();   // Se está grabando el Video

            addFileToMediaScanner(new File(archivoSalida));

            ultimaCaptura = 0;
            showToast(false, Toast.LENGTH_SHORT, actividad.getString(R.string.message_startVideo, directorio.getAbsolutePath() + "/VideoEspia_" + SDF.format(new Date()) + ".mp4"));
            setEstado(ESTADO_VIDEO_GRABADO);
        } catch (IllegalStateException e) {
            iniciar.w(this, e);
            showToast(true, Toast.LENGTH_SHORT, "No se ha podido iniciar la grabación de vdeo");
            if (grabar != null) {
                grabar.reset();
                grabar.release();
            }
            try {
                camara.lock();
                camara.reconnect();
            } catch (Throwable e1) {
            }
            Message msg = new Message();
            msg.what = Main_Principal.WHAT_SHOW_FAILED_PROCESS;
            msg.obj = new ProcesosDetenidos(e
                    , "\n" +
                    "No se ha podido iniciar la grabación de video.\n\n" +
                    "Esta característica todavía se está probando.\n\n" +
                    "Usted puede intentar otra configuración de la calidad.\n\n" +
                    "Informes que le ayudará a resolver los problemas"
                    , "Reporte"
                    , "OK", false, null);
            controlador.sendMessage(msg);

            Intent intento = new Intent(actividad, Llamado_Camara.class);
            Messenger mensaje = new Messenger(controladorCamra);
            intento.putExtra(Llamado_Camara.EXTRA_MESSENGER, mensaje);
            intento.putExtra(Llamado_Camara.EXTRA_ACTION, Llamado_Camara.QUE_DETIENE);
            actividad.stopService(intento);

            try {
                File fallaArchivo = new File(archivoSalida);
                if (fallaArchivo.exists()) {
                    fallaArchivo.delete();
                }
            } catch (Exception e2) {
            }

        } catch (IOException e) {
            iniciar.w(this, e);
            showToast(true, Toast.LENGTH_SHORT, "No se ha podido iniciar la grabación de video");
            if (grabar != null) {
                grabar.reset();
                grabar.release();
            }
            try {
                camara.lock();
                camara.reconnect();
            } catch (Throwable e1) {
            }
            Message msg = new Message();
            msg.what = Main_Principal.WHAT_SHOW_FAILED_PROCESS;
            msg.obj = new ProcesosDetenidos(e
                    , "\n" +
                    "No se ha podido iniciar la grabación de vdeo.\nEsta Característica todavía se está probando.\n\n" +
                    "Usted puede intentar otra configuración de la calidad.\n\n" +
                    "Informes que le ayudará a resolver los problemas"
                    , "Reporte"
                    , "OK", false, null);
            controlador.sendMessage(msg);

            Intent intento = new Intent(actividad, Llamado_Camara.class);
            Messenger mensaje = new Messenger(controladorCamra);
            intento.putExtra(Llamado_Camara.EXTRA_MESSENGER, mensaje);
            intento.putExtra(Llamado_Camara.EXTRA_ACTION, Llamado_Camara.QUE_DETIENE);
            actividad.stopService(intento);

            try {
                File archivoFallido = new File(archivoSalida);
                if (archivoFallido.exists()) {
                    archivoFallido.delete();
                }
            } catch (Exception e2) {
            }
        } catch (RuntimeException e) {
            iniciar.w(this, e);
            showToast(true, Toast.LENGTH_SHORT, "\n" +
                    "No se ha podido iniciar la grabación de video");
            if (grabar != null) {
                grabar.reset();
                grabar.release();
            }
            try {
                camara.lock();
                camara.reconnect();
            } catch (Throwable e1) {
            }
            Message msg = new Message();
            msg.what = Main_Principal.WHAT_SHOW_FAILED_PROCESS;
            msg.obj = new ProcesosDetenidos(e
                    , "No se ha podido iniciar la grabación de vdeo.\nEsta Característica todavía se está probando.\n\n" +
                    "Usted puede intentar otra configuración de la calidad.\n\n" +
                    "Informes que le ayudará a resolver los problemas"
                    , "Report"
                    , "OK", false, null);
            controlador.sendMessage(msg);

            Intent intento = new Intent(actividad, Llamado_Camara.class);
            Messenger mensaje = new Messenger(controladorCamra);
            intento.putExtra(Llamado_Camara.EXTRA_MESSENGER, mensaje);
            intento.putExtra(Llamado_Camara.EXTRA_ACTION, Llamado_Camara.QUE_DETIENE);
            actividad.stopService(intento);

            try {
                File archivoFallido = new File(archivoSalida);
                if (archivoFallido.exists()) {
                    archivoFallido.delete();
                }
            } catch (Exception e2) {
            }
        } finally {
        }
    }

    public void iniciarTamanioPrevio(int maxWidth) {
        int w = configuracion.getAvanceTamanioImagen() + 10;
        int max = maxWidth * 3 / 4;
        if (w > max) {
            w = max;
        }
        configuracion.setAvanceTamanioImagen(w);
        refreshImagenTamanio();
    }

    public void detectarTamanio() {
        int w = configuracion.getAvanceTamanioImagen() - 10;
        if (w < 1) {
            w = 1;
        }
        configuracion.setAvanceTamanioImagen(w);
        refreshImagenTamanio();
    }

    @Override
    public void onZoomChange(int arg0, boolean arg1, Camera arg2) {
        // TODO Auto-generated metodo
    }

    @Override
    public void onPreviewFrame(byte[] data, Camera camera) {
        //		iniciar.v(this, "onPreviewFrame()");
        chasquido = data;
    }

    @Override
    public void onAutoFocus(boolean success, Camera camera) {
        iniciar.v(this, "Autoenfocado(exitoso:" + success + ")");
        estaEncendidoAutoEnfocado = false;
        if (chasquido == null) {
            showToast(true, Toast.LENGTH_SHORT, "\n" +
                    "Los datos de imagen no se encontraron");
            iniciar.w(this, "\n" +
                    "Los datos de imagen no se encontraron");
            setEstado(ESTADO_ID);
        } else if (parametrosCamara == null) {
            showToast(true, Toast.LENGTH_SHORT, "\n" +
                    "parámetros de la imagen no encontrado");
            iniciar.w(this, "\n" +
                    "parámetros de la imagen no encontrado");
            setEstado(ESTADO_ID);
        } else if (chasquido != null) {
            long completeAutofocus = System.currentTimeMillis();
            synchronized (camera) {
                //					iniciar.d(this, "ultimaCaptura : " + ultimaCaptura + "|" + avgTiempoAutoEnfocado);
                try {
                    if (!estaTomandoFotos) {
                        if (avgTiempoAutoEnfocado == -1) {
                            avgTiempoAutoEnfocado = completeAutofocus - ultimoAutoEnfocado;
                        } else {
                            avgTiempoAutoEnfocado += completeAutofocus - ultimoAutoEnfocado;
                            avgTiempoAutoEnfocado /= 2;
                        }
                        iniciar.d(this, "\n" +
                                "Promedio de tiempo de enfoque : " + avgTiempoAutoEnfocado);

                        if (estaEnLaMasAltaResolucion) {
                            estaTomandoFotos = true;
                            iniciar.d(this, "\n" +
                                    "llamando CapturarFoto");
                            camera.takePicture(this, null, null, this);
                            ultimaCaptura = System.currentTimeMillis();
                        } else {
                            guardarImagen(true);
                        }
                    } else {
                        iniciar.w(this, "\n" +
                                "Haciendo caso omiso de la solicitud de captura, ya que todavía en la toma de fotografía de en medio");
                    }

                    if (estado == ESTADO_IMAGEN_UNICA || estado == ESTADO_IMAGEN_CARA) {
                        if (estaCamaraConfigurada) {
                            try {
                                camera.cancelAutoFocus();
                            } catch (RuntimeException e) {
                            }
                        }
                    }
                } catch (IOException e) {
                    iniciar.w(this, e);
                    if (estaCamaraConfigurada) {
                        try {
                            camera.cancelAutoFocus();
                        } catch (RuntimeException e2) {
                        }
                    }
                }
            }
        }
    }

    private void guardarImagen(boolean yuv) throws IOException {
        iniciar.d(this, "Llamando a GuardarImagen(yuv:" + yuv + ")");
        FileOutputStream archivocon = null;
        try {
            File directorio = new File(configuracion.getGuardarDireccion());
            if (!directorio.exists()) {
                directorio.mkdir();
            }
            File archivo = new File(directorio.getAbsolutePath() + "/FotoEspia_" + SDF.format(new Date()) + ".jpg");
            archivocon = new FileOutputStream(archivo);
            int rotacion = configuracion.getRotacionImagen();
            int[] rotarImagen = new int[2];
            if (defaultOrientacion == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) {
                rotarImagen[0] = 90;
                rotarImagen[1] = -90;
            } else if (defaultOrientacion == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
                rotarImagen[0] = 0;
                rotarImagen[1] = 0;
            } else if (defaultOrientacion == ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT) {
                rotarImagen[0] = 180;
                rotarImagen[1] = 180;
            } else if (defaultOrientacion == ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT) {
                rotarImagen[0] = -90;
                rotarImagen[1] = 90;
            }

            int[] rgbDatos = null;
            if (yuv) {
                rotacion += rotarImagen[camaraId];
                if (rotacion > 360) {
                    rotacion -= 360;
                }
                if (!configuracion.estaYUVDecodeAlternativo()) {
                    Size size = parametrosCamara.getPreviewSize();
                    YuvImage yuvImagen = new YuvImage(chasquido, parametrosCamara.getPreviewFormat(),
                            size.width, size.height, null);
                    yuvImagen.compressToJpeg(new Rect(0, 0, size.width, size.height), 100, archivocon);
                    int width = yuvImagen.getWidth();
                    int height = yuvImagen.getHeight();
                    yuvImagen = null;
                    archivocon.close();
                    archivocon = null;
                    boolean rotationExitosa = true;
                    if (rotacion != 0) {
                        rotationExitosa = rotarArchivoImagen(archivo, rotacion);
                    }
                    String mensaje = archivo.getAbsolutePath() + " : " + width + "x" + height;
                    if (!rotationExitosa) {
                        mensaje += " (\n" +
                                "No hay memoria suficiente para girar la imagen)";
                    }
                    showToast(false, Toast.LENGTH_SHORT, mensaje);
                } else {
                    iniciar.d(this, "\n" +
                            "Usando de encargo YUV decodificador");
                    Size size = parametrosCamara.getPreviewSize();
                    rgbDatos = new int[size.width * size.height];
                    decodeYUV(rgbDatos, chasquido, size.width, size.height);
                    Bitmap bitmap = Bitmap.createBitmap(rgbDatos, size.width, size.height, Bitmap.Config.ARGB_8888);
                    int width = bitmap.getWidth();
                    int height = bitmap.getHeight();
                    if (rotacion != 0) {
                        iniciar.v(this, "rotando imagen : " + rotacion);
                        Matrix m = new Matrix();
                        m.setRotate(rotacion, (float) bitmap.getWidth() / 2, (float) bitmap.getHeight() / 2);
                        Bitmap bitmap2 = Bitmap.createBitmap(bitmap, 0, 0, size.width, size.height, m, false);
                        bitmap.recycle();
                        bitmap = null;
                        bitmap2.compress(CompressFormat.JPEG, 100, archivocon);
                        bitmap2.recycle();
                        bitmap2 = null;
                    } else {
                        bitmap.compress(CompressFormat.JPEG, 100, archivocon);
                        bitmap.recycle();
                    }
                    showToast(false, Toast.LENGTH_SHORT, archivo.getAbsolutePath() + " : " + width + "x" + height);
                }
            } else {
                archivocon.write(chasquido);
                archivocon.close();
                boolean rotationSuccess = true;
                if (rotacion != 0) {
                    rotationSuccess = rotarArchivoImagen(archivo, rotacion);
                }
                String msg = archivo.getAbsolutePath() + " : " + parametrosCamara.getPictureSize().width + "x" + parametrosCamara.getPictureSize().height;
                if (!rotationSuccess) {
                    msg += " (no hay memoria suficiente para rotar la imagen)";
                }
                showToast(false, Toast.LENGTH_SHORT, msg);
            }
            if (configuracion.getVibrar()) {
                Vibrator v = (Vibrator) actividad.getSystemService(Context.VIBRATOR_SERVICE);
                v.vibrate(configuracion.getTiempoVibrar());
            }
            addFileToMediaScanner(archivo);
            if (configuracion.estaHabilitadoGmail()) {
                sendEmailViaGMail(archivo);
            }

            if (estado == ESTADO_IMAGEN_UNICA) {
                setEstado(ESTADO_ID);
            }

            ultimaCaptura = System.currentTimeMillis();
        } catch (RuntimeException e) {
            iniciar.w(this, e);
            Message msg = new Message();
            msg.what = Main_Principal.WHAT_SHOW_FAILED_PROCESS;
            msg.obj = new ProcesosDetenidos(e
                    , "\n" +
                    "No se ha podido guardar la imagen. Por favor trate de cambiar la resolución de la imagen en el establecimiento.\n\n" +
                    "El envío del informe ayudará a resolver el problema."
                    , "Enviando Reporte"
                    , "OK", false, null);
            controlador.sendMessage(msg);
        } finally {
            if (archivocon != null) {
                try {
                    archivocon.close();
                } catch (IOException e) {
                }
            }
        }
    }

    private boolean rotarArchivoImagen(File archivo, int rotation) throws FileNotFoundException {
        iniciar.v(this, "ArchivoRotarImagen(rotation:" + rotation + ")");
        Boolean rotacionExitosa = false;
        Bitmap bitmapOrientacion = null;
        Bitmap bitmapRotacion = null;
        FileOutputStream Archivocon = null;
        try {
            bitmapOrientacion = BitmapFactory.decodeFile(archivo.getAbsolutePath());
            Matrix matriz = new Matrix();
            matriz.postRotate(rotation);
            bitmapRotacion = Bitmap.createBitmap(bitmapOrientacion, 0, 0,
                    bitmapOrientacion.getWidth(), bitmapOrientacion.getHeight(), matriz, true);
            bitmapOrientacion.recycle();
            bitmapOrientacion = null;
            Archivocon = new FileOutputStream(archivo);
            bitmapRotacion.compress(CompressFormat.JPEG, 100, Archivocon);
            bitmapRotacion.recycle();
            bitmapRotacion = null;
            rotacionExitosa = true;
        } catch (OutOfMemoryError e) {
            iniciar.w(this, e);
            System.gc();
        } finally {
            if (bitmapOrientacion != null) {
                bitmapOrientacion.recycle();
                bitmapOrientacion = null;
            }
            if (bitmapRotacion != null) {
                bitmapRotacion.recycle();
                bitmapRotacion = null;
            }
            if (Archivocon != null) {
                try {
                    Archivocon.close();
                } catch (IOException e) {
                }
                Archivocon = null;
            }
        }
        return rotacionExitosa;
    }

    private void addFileToMediaScanner(File f) {
        iniciar.v(this, "AñadirArchivoAMedia(f:" + f.getPath() + ")");
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        Uri contentUri = Uri.fromFile(f);
        mediaScanIntent.setData(contentUri);
        actividad.sendBroadcast(mediaScanIntent);
    }

    public void decodeYUV(int[] out, byte[] fg, int width, int height)
            throws NullPointerException, IllegalArgumentException {
        iniciar.v(this, "DecodificarYUV(out:" + out + "|fg:" + (fg != null ? fg.length : null) + "|w:" + width + "|h:" + height + ")");
        int sz = width * height;
        if (out == null)
            throw new NullPointerException("buffer de salida no es nulo");
        if (out.length < sz)
            throw new IllegalArgumentException("buffer fuera de tamaño " + out.length
                    + " < minimum " + sz);
        if (fg == null)
            throw new NullPointerException("buffer 'fg' is null");

        if (fg.length < sz)
            throw new IllegalArgumentException("buffer fg size " + fg.length
                    + " < minimo " + sz);

        int i, j;
        int Y, Cr = 0, Cb = 0;
        for (j = 0; j < height; j++) {
            int pixPtr = j * width;
            final int jDiv2 = j >> 1;
            for (i = 0; i < width; i++) {
                Y = fg[pixPtr];
                if (Y < 0)
                    Y += 255;
                if ((i & 0x1) != 1) {
                    final int cOff = sz + jDiv2 * width + (i >> 1) * 2;
                    Cb = fg[cOff];
                    if (Cb < 0)
                        Cb += 127;
                    else
                        Cb -= 128;
                    Cr = fg[cOff + 1];
                    if (Cr < 0)
                        Cr += 127;
                    else
                        Cr -= 128;
                }
                int R = Y + Cr + (Cr >> 2) + (Cr >> 3) + (Cr >> 5);
                if (R < 0)
                    R = 0;
                else if (R > 255)
                    R = 255;
                int G = Y - (Cb >> 2) + (Cb >> 4) + (Cb >> 5) - (Cr >> 1)
                        + (Cr >> 3) + (Cr >> 4) + (Cr >> 5);
                if (G < 0)
                    G = 0;
                else if (G > 255)
                    G = 255;
                int B = Y + Cb + (Cb >> 1) + (Cb >> 2) + (Cb >> 6);
                if (B < 0)
                    B = 0;
                else if (B > 255)
                    B = 255;
                out[pixPtr++] = (0xff000000 + (B << 16) + (G << 8) + R);
            }
        }

    }

    @Override
    public void onShutter() {
        iniciar.v(this, "enObturador()");
//		unmute();
    }

    @Override
    public void onPictureTaken(byte[] dato, Camera camara) {
        iniciar.v(this, "enImagenCapturada(datos" + (dato != null ? dato.length : null) + ")");
        chasquido = dato;
        try {
            guardarImagen(false);
            camara.startPreview();
            estaTomandoFotos = false;
        } catch (IOException e) {
            iniciar.w(this, e);
        }
    }

    public void setEstado(int estado) {
        iniciar.v(this, "setEstado(estado:" + estado + ")|Accion:" + accionAjuste);
        estaEncendidoAutoEnfocado = false;
        if (this.accionAjuste == true && estado == ESTADO_ID) {
            actividad.finish();
        }
        if (estado == this.estado) {
            return;
        }
        if (isUIDisplayed) {
            Message msg = new Message();
            msg.what = Main_Principal.WHAT_SET_STATE_UI;
            msg.arg1 = this.estado;
            this.estado = estado;
            msg.arg2 = estado;
            if (configuracion.getDeshabilitarSevicioBackground()) {
                msg.obj = Boolean.TRUE;
            }
            controlador.sendMessage(msg);
        } else {
            this.estado = estado;
        }
    }

    public void pantallaNegraClic() {
        if (estado == ESTADO_ID) {
            capturaImagen();
        }
    }

    public boolean VistaEnEscala(ScaleGestureDetector sgd) {
        iniciar.v(this, "en Escala " + sgd.getScaleFactor() + "-" + parametrosCamara.getMaxZoom());
        if (parametrosCamara.isZoomSupported() || parametrosCamara.isSmoothZoomSupported()) {
            if (sgd.getScaleFactor() > 1) {
                if (parametrosCamara.getZoom() < parametrosCamara.getMaxZoom()) {
                    zoomCorriente = parametrosCamara.getZoom() + 1;
                    correrZoom = true;
                    if (parametrosCamara.isSmoothZoomSupported()) {
                        if (!correrZoom) {
                            camara.startSmoothZoom(zoomCorriente);
                        }
                    } else {
                        parametrosCamara.setZoom(zoomCorriente);
                        camara.setParameters(parametrosCamara);
                    }
                    iniciar.i(this, "Zoom a : " + zoomCorriente);
                }
            } else if (sgd.getScaleFactor() < 1) {
                if (parametrosCamara.getZoom() > 0) {
                    zoomCorriente = parametrosCamara.getZoom() - 1;
                    correrZoom = true;
                    if (parametrosCamara.isSmoothZoomSupported()) {
                        if (!correrZoom) {
                            camara.startSmoothZoom(zoomCorriente);
                        }
                    } else {
                        parametrosCamara.setZoom(zoomCorriente);
                        camara.setParameters(parametrosCamara);
                    }
                    iniciar.i(this, "Zoom para : " + zoomCorriente);
                }
            }
        } else {
            if (!seHaDesplegadoZoom) {
                seHaDesplegadoZoom = true;
                showToast(true, Toast.LENGTH_SHORT, "Zoom no fue soportado");
            }
        }
        return true;
    }

    private boolean chequearColisionAnterior() {
        boolean soloColision = configuracion.estaColisionado();
        if (!soloColision) {
            return false;
        }
        final File archivo = new File(configuracion.getDireccionColision());
        if (!archivo.exists()) {
            showToast(true, Toast.LENGTH_LONG, "Fue generado un Error pero no fue Reportado");
            return false;
        }

        File tipoArchivo = new File(configuracion.getDireccionTipoColision());
        int tipo = 0;
        if (tipoArchivo.exists()) {
            FileInputStream f;
            try {
                f = new FileInputStream(tipoArchivo);
                tipo = f.read();
            } catch (FileNotFoundException e) {
            } catch (IOException e) {
            }
        }


        Message mensaje = new Message();
        mensaje.what = Main_Principal.WHAT_SHOW_CRASH_DIALOG;
        mensaje.arg1 = tipo;
        controlador.sendMessage(mensaje);
        return true;
    }

    public String reporteError() {
        StringBuffer info = new StringBuffer();
        info.append("Id:Camara ").append(this.camaraId).append("\n");
        info.append("defaultOrientacion: ").append(this.defaultOrientacion).append("\n");
        info.append("zoomCorriente: ").append(this.zoomCorriente).append("\n");
        info.append("TitularListo: ").append(this.estaControlListo).append("\n");
        info.append("ConfiguracionCamara: ").append(this.estaCamaraConfigurada).append("\n");
        info.append("ImagenAltaResol: ").append(this.estaEnLaMasAltaResolucion).append("\n");
        info.append("PantallaNegra: ").append(this.estaPantallaNegra).append("\n");
        info.append("TomandoFoto: ").append(this.estaTomandoFotos).append("\n");
        info.append("AutoEnfocado ").append(this.estaEncendidoAutoEnfocado).append("\n");
        info.append("Accion: ").append(this.accionAjuste).append("\n");
        info.append("Estado: ").append(this.estado).append("\n");
        info.append("TamañoPevio: ");
        if (this.Tamanio != null) {
            info.append(this.Tamanio.width).append("x").append(this.Tamanio.height).append("\n");
        } else {
            info.append("null\n");
        }
        info.append("tamaño de la Captura: ");
        if (this.capturarTamanio != null) {
            info.append(this.capturarTamanio.width).append("x").append(this.capturarTamanio.height).append("\n");
        } else {
            info.append("null\n");
        }
        info.append("ParametrosCamara: ");
        try {
            Camera.Parameters temp = camara.getParameters();
            if (temp != null) {
                this.parametrosCamara = temp;
            }
        } catch (RuntimeException e) {
        }
        if (this.parametrosCamara != null) {
            info.append("\n" + "-modoEnfoque(): ").append(this.parametrosCamara.getFocusMode());
            info.append("\n" + "-modoTamanioPrevio: ");
            if (this.parametrosCamara.getPreviewSize() == null) {
                info.append("null");
            } else {
                info.append(this.parametrosCamara.getPreviewSize().width).append("x").append(this.parametrosCamara.getPreviewSize().height);
            }
            info.append("\n" + "-FormatoPrevio: ").append(this.parametrosCamara.getPreviewFormat());
            info.append("\n" + "-ApoyoVistaPrevia(): ");
            for (Integer i : this.parametrosCamara.getSupportedPreviewFormats()) {
                info.append(i).append(",");
            }
            info.append("\n" + "-ApoyoTamanioPrevio(): ");
            for (Camera.Size i : this.parametrosCamara.getSupportedPreviewSizes()) {
                info.append(i.width).append("x").append(i.height).append(",");
            }
            info.append("\n" + "-TamanioImagen: ").append(this.parametrosCamara.getPictureSize().width).append("x").append(this.parametrosCamara.getPictureSize().height);
            info.append("\n" + "-FormatoImagen: ").append(this.parametrosCamara.getPictureFormat());
            info.append("\n" + "-ApoyoFormatoImagen(): ");
            for (Integer i : this.parametrosCamara.getSupportedPictureFormats()) {
                info.append(i).append(",");
            }
            info.append("\n" + "-ApoyoTamanioImagen(): ");
            for (Camera.Size i : this.parametrosCamara.getSupportedPictureSizes()) {
                info.append(i.width).append("x").append(i.height).append(",");
            }
        } else {
            info.append("null\n");
        }
        info.append("\nactual calidad-video: ").append(this.corrienteCamcorderProfileId).append("\n");
        info.append("\ncualidades-video camara-trasera: ");
        if (this.calidadesVideo != null && this.calidadesVideo[0] != null) {
            for (String quality : calidadesVideo[0]) {
                info.append(quality).append(", ");
            }
        } else {
            info.append("\nnull\n");
        }
        info.append("\ncualidades-video camara-delantera: ");
        if (this.calidadesVideo != null && this.calidadesVideo.length >= 2 && this.calidadesVideo[1] != null) {
            for (String quality : calidadesVideo[1]) {
                info.append(quality).append(", ");
            }
        } else {
            info.append("\nnull\n");
        }
        return info.toString();
    }

    public void forzarOrientacion() {
        iniciar.v(this, "forzarOrientacion() para " + defaultOrientacion);
        actividad.setRequestedOrientation(defaultOrientacion);
    }

    public void enviaremailColision(boolean previo) {
        iniciar.DeshabilitarIngreso();
        if (!previo) {
            iniciar.eliminarRegistroErrores();
            if (configuracion.getIngresando()) {
                iniciar.renombrarErrores();
            }
        }
        final File archivo = new File(configuracion.getDireccionColision());
        ManejoColisiones.getInstancia(null, null).enviarEmail(archivo);
    }

    public boolean PresionarBajarVolumen() {
        iniciar.v(this, "PresionarBajarVolumen()");
        String tipo = configuracion.getAccionVolumenAbajo();
        if (tipo.equals("capturar")) {
            capturaImagen();
            return true;
        } else if (tipo.equals("auto")) {
            CapturaautomticaImagen();
            return true;
        } else if (tipo.equals("cara")) {
            autoCapuraCara();
            return true;
        } else if (tipo.equals("video")) {
            grabandoVideo();
            return true;
        }
        return false;
    }

    public boolean PresionarSubirVolumen() {
        iniciar.v(this, "PresionarSubirVolumen()");
        String tipo = configuracion.getAccionVolumenArriba();
        if (tipo.equals("capturar")) {
            capturaImagen();
            return true;
        } else if (tipo.equals("auto")) {
            CapturaautomticaImagen();
            return true;
        } else if (tipo.equals("cara")) {
            autoCapuraCara();
            return true;
        } else if (tipo.equals("video")) {
            grabandoVideo();
            return true;
        }
        return false;
    }

    public void uiResumen(SurfaceView vistaSuperficie) {
        isUIDisplayed = true;
        if (!reporteColision) {
            if (Llamado_Camara.estado == Llamado_Camara.QUE_DETIENE) {
                modo = Utilidades.getSonido(actividad);
                Utilidades.setSonido(actividad, AudioManager.RINGER_MODE_SILENT);
                startCamera(vistaSuperficie);
                configuracion.resetear();
                if (configuracion.getIngresando()) {
                    iniciar.PermitirIngreso(actividad);
                } else {
                    iniciar.DeshabilitarIngreso();
                }
                if (estaPantallaNegra && configuracion.MostrarToast()) {
                    showToast(true, Toast.LENGTH_SHORT, actividad.getString(R.string.hint_blackmode));
                }
            } else if (Llamado_Camara.estado == Llamado_Camara.QUE_INICIA_AUTOTOMADO
                    || Llamado_Camara.estado == Llamado_Camara.QUE_INICIA_TOMADO_CARA
                    || Llamado_Camara.estado == Llamado_Camara.QUE_INICIA_GRABACION_VIDEO) {
                final AlertDialog ad = new AlertDialog.Builder(actividad).create();
                ad.setTitle("Corriendo Proceso");
                if (Llamado_Camara.estado == Llamado_Camara.QUE_INICIA_AUTOTOMADO) {
                    ad.setMessage("modo Auto está activado");
                } else if (Llamado_Camara.estado == Llamado_Camara.QUE_INICIA_TOMADO_CARA) {
                    ad.setMessage("modo Cara está activado");
                } else {
                    ad.setMessage("modo Video está activado");
                }
                ad.setButton(AlertDialog.BUTTON_POSITIVE, "Detener", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(actividad, Llamado_Camara.class);
                        actividad.stopService(intent);
                        intent = new Intent(actividad, ActividadCamaraEspia.class);
                        actividad.startActivity(intent);
                        actividad.finish();
                    }
                });
                ad.setButton(AlertDialog.BUTTON_NEGATIVE, "Esconder", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        actividad.finish();
                    }
                });
                ad.show();
            }
        }
    }

    public void uiPausa() {
        iniciar.v(this, "Pausa()");
        isUIDisplayed = false;
        if (Main_Controlador.this.accionAjuste) {
            desactivarAccionAjuste();
        }
        if (configuracion.getDeshabilitarSevicioBackground() || estado == ESTADO_ID || estado == ESTADO_IMAGEN_UNICA) {
            detenerCamara();
            Utilidades.setSonido(actividad, modo);
            estaControlListo = false;
        } else {
            actividad.finish();
        }
    }

    public boolean presionarAtras() {
        if (estaPantallaNegra) {
            configuracion.setAvanceTamanioImagen(tempTamanio);
            actividad.finish();
            return true;
        } else if (estado != ESTADO_ID) {
            Intent intent = new Intent(actividad, Llamado_Camara.class);
            actividad.stopService(intent);
        }
        return false;

    }

    public boolean presionarMenu() {
        if (estaPantallaNegra) {
            cambiarAPantallaNegra();
            return true;
        }
        return false;
    }

    public boolean enPantallaNegra(ScaleGestureDetector sgd) {
        if (sgd.getScaleFactor() < 1 && estaPantallaNegra) {
            cambiarAPantallaNegra();
        }
        return true;
    }

    public void setActividad(Activity actividad) {
        this.actividad = actividad;
    }

    public void setUIManejador(Handler controlador) {
        this.controlador = controlador;
    }

    public void activarAccionAjuste() {
        this.accionAjuste = true;
        if (!configuracion.getDeshabilitarSevicioBackground()) {
            tempTamanio = configuracion.getAvanceTamanioImagen();
            configuracion.setAvanceTamanioImagen(1);
        }
        refreshImagenTamanio();
    }

    public void desactivarAccionAjuste() {
        this.accionAjuste = false;
        configuracion.setAvanceTamanioImagen(tempTamanio);
    }

    public void LlamarFuncionAjuste(final int action) {
        iniciar.v(this, "LlmarAccion(accion:" + action + ")");
        new Thread() {
            @Override
            public void run() {
                activarAccionAjuste();

                if (Llamado_Camara.estado == Llamado_Camara.QUE_INICIA_AUTOTOMADO
                        || Llamado_Camara.estado == Llamado_Camara.QUE_INICIA_TOMADO_CARA
                        || Llamado_Camara.estado == Llamado_Camara.QUE_INICIA_GRABACION_VIDEO) {
                    Intent intent = new Intent(actividad, Llamado_Camara.class);
                    actividad.stopService(intent);
                    actividad.finish();
                    return;
                }

                while (!estaCamaraConfigurada || chasquido == null) {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                    }
                }
                if (configuracion.getDeshabilitarSevicioBackground()) {
                    cambiarAPantallaNegra();
                }
                switch (action) {
                    case 1:
                        capturaImagen();
                        break;
                    case 2:
                        CapturaautomticaImagen();
                        break;
                    case 3:
                        autoCapuraCara();
                        break;
                    case 4:
                        grabandoVideo();
                        break;
                    default:
                        actividad.finish();
                        break;
                }
            }
        }.start();
    }

    private void autoCapturadeImagenIniciar() {
        setEstado(ESTADO_AUTO_IMAGEN);
        showToast(false, Toast.LENGTH_SHORT, actividad.getString(R.string.message_startAuto, (configuracion.getAutoCapturar() / 1000)));
        IniciarAutoEnfocado();
        if (Main_Controlador.this.accionAjuste && !configuracion.getDeshabilitarSevicioBackground()) {
            abrirAjustes();
        }
    }

    private void autoCapturadeImagenDetener() {
        setEstado(ESTADO_ID);
        if (!isUIDisplayed) {
            uiPausa();
        } else {
            showToast(false, Toast.LENGTH_SHORT, R.string.message_stopAuto);
        }
    }

    private void autoTareaCapturadeImagenIniciada() {
        autoTareaImagen = new AutoShootLocalAsync(configuracion.getAutoCapturar());
        autoTareaImagen.start();
    }

    private void tareaAutoCapturaDeImagenDetener() {
    }

    public void grabadoVideoIniciado() {
        iniciarGrabadoVideo();
        if (estado == ESTADO_VIDEO_GRABADO && Main_Controlador.this.accionAjuste && !configuracion.getDeshabilitarSevicioBackground()) {
            abrirAjustes();//minimizar
        }
    }

    public void grabajodeVideoDetener() {
        if (estado == ESTADO_VIDEO_GRABADO) {
            detenerGrabacionVideo();
            if (!isUIDisplayed) {
                uiPausa();
            }
        }
    }

    @TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
    public void autoFaceCapturaImagenIniciada() {
        setEstado(ESTADO_IMAGEN_CARA);
        camara.setFaceDetectionListener(new FaceDetectionListener() {
            @Override
            public void onFaceDetection(Face[] faces, Camera camera) {
                long delay = configuracion.getAutoCapturar();
                if (System.currentTimeMillis() - ultimaCaptura > delay - avgTiempoAutoEnfocado && faces.length > 0) {
                    iniciar.d(this, "Cara Detectada : " + faces.length);
                    IniciarAutoEnfocado();
                }
            }
        });
        if (parametrosCamara.getMaxNumDetectedFaces() > 0) {
            camara.startFaceDetection();
            showToast(false, Toast.LENGTH_SHORT, R.string.message_startFace);
        }
        if (estado == ESTADO_IMAGEN_CARA && Main_Controlador.this.accionAjuste && !configuracion.getDeshabilitarSevicioBackground()) {
            abrirAjustes();//minimize
        }
    }

    @TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
    public void autoCapturaImagenDetenida() {
        setEstado(ESTADO_ID);
        camara.setFaceDetectionListener(null);
        if (parametrosCamara.getMaxNumDetectedFaces() > 0) {
            camara.stopFaceDetection();
            showToast(false, Toast.LENGTH_SHORT, R.string.message_stopFace);
        }
        if (!isUIDisplayed) {
            uiPausa();
        }
    }

    public void sendEmailViaGMail(final File file) {
        imagenesParaMail.add(file);
        if (tareaMail == null || !tareaMail.isAlive()) {
            tareaMail = new GMailSenderTask();
            tareaMail.start();
        }
    }

    static class MainControllerHandler extends Handler {
        private Main_Controlador mainControlador;

        public MainControllerHandler(Main_Controlador mainControlador) {
            this.mainControlador = mainControlador;
        }

        @Override
        public void handleMessage(Message msg) {
            mainControlador.iniciar.v(mainControlador + ".manejarCamara", "manejarMensaje(mensaje:" + msg.what + "|" + msg.arg1 + "|" + msg.arg2 + ")");
            switch (msg.what) {
                case QUE_INICIAR_AUTO_TOMADO:
                    mainControlador.autoCapturadeImagenIniciar();
                    break;
                case QUE_CONTINUAR_AUTO_TOMADO:
                    mainControlador.IniciarAutoEnfocado();
                    break;
                case QUE_DETENER_AUTO_TOMADO:
                    mainControlador.autoCapturadeImagenDetener();
                    break;
                case QUE_INICIAR_VIDEO:
                    mainControlador.grabadoVideoIniciado();
                    break;
                case QUE_DETENER_VIDEO:
                    mainControlador.grabajodeVideoDetener();
                    break;
                case QUE_INICIAR_TOMADO_CARA:
                    mainControlador.autoFaceCapturaImagenIniciada();
                    break;
                case QUE_DETENER_TOMDO_CARA:
                    mainControlador.autoCapturaImagenDetenida();
                    break;
            }
        }
    }

    private class AutoShootLocalAsync extends Thread {

        int sleep = 0;

        public AutoShootLocalAsync(int sleep) {
            this.sleep = sleep;
        }

        @Override
        public void run() {
            try {
                while (estado == ESTADO_AUTO_IMAGEN) {
                    iniciar.v(this, "corriendo(dormir:" + sleep + ")");
                    Thread.sleep(sleep);
                    if (estado == ESTADO_AUTO_IMAGEN) {
                        IniciarAutoEnfocado();
                    }
                }
            } catch (InterruptedException e) {
            }
        }
    }

    class GMailSenderTask extends Thread {

        @Override
        public void run() {
            EnvioMensaje envia = new EnvioMensaje(configuracion.getAutoGmailUsuario(), configuracion.getAutoGmailContrasenia());
            int contador = 0;
            File archivo = null;
            while (imagenesParaMail.size() > 0) {
                try {
                    if (!Utilidades.estaLinea(actividad)) {
                        iniciar.d(this, "No hay red, sueño 5 segundos");
                        sleep(5000);
                        continue;
                    }
                    contador++;
                    archivo = imagenesParaMail.get(0);
                    envia.enviarCorreo(
                            "  " + SDF.format(new Date())
                            , configuracion.getAutoGMailRecivido()
                            , archivo);
                    imagenesParaMail.remove(archivo);
                    contador = 0;
                } catch (AuthenticationFailedException e) {
                    iniciar.e(this, e);
                    if (contador == 1) {
                        showToast(false, Toast.LENGTH_SHORT, actividad.getString(R.string.error_auto_email_auth));
                    } else if (contador > 5) {
                        imagenesParaMail.remove(archivo);
                        contador = 0;
                    }
                } catch (Exception e) {
                    if (contador == 1) {
                        showToast(false, Toast.LENGTH_SHORT, actividad.getString(R.string.error_auto_email_others));
                    } else if (contador > 5) {
                        imagenesParaMail.remove(archivo);
                        contador = 0;
                    }
                    iniciar.e(this, e);
                }
            }
        }

    }
}
