
package com.jwork.arteaga;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.ScaleGestureDetector.OnScaleGestureListener;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.jwork.arteaga.Capa_Negocio.Fabrica;
import com.jwork.arteaga.Capa_Datos.UtilidadInicio;
import com.jwork.arteaga.Capa_Datos.Utilidades;


public class Main_Fragmentos extends Fragment implements OnClickListener, OnTouchListener, Callback, OnScaleGestureListener {

    private Main_Controlador controller;
    private Fabrica fabrica;
    private Main_Principal handler;
    private UtilidadInicio log;
    private Activity activity;

    private LinearLayout layoutCenter;
    private LinearLayout layoutBlack;
    private Button btnAuto;
    private Button btnBlack;
    private Button btnCapture;
    private Button btnFace;
    private Button btnVideo;
    private Button btnSwitchCam;
    private Button btnDecSize;
    private Button btnIncSize;
    private Button btnHelp;
    private Button btnSetting;
    private SurfaceView vistaSuperficie;
    private SurfaceHolder shPreview;
    private ScaleGestureDetector sgdPreview;
    private ScaleGestureDetector sgdBlack;
    private View view;

    public Main_Fragmentos() {
        this.fabrica = Fabrica.getInstancia();
        this.log = UtilidadInicio.getInstancia();
        log.v(this, "constructor()");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        log.v(this, "onCreateView()");
        this.activity = getActivity();
        view = inflater.inflate(R.layout.fragment_main, container);
        this.handler = fabrica.getMainFragmentos(this);
        this.controller = fabrica.getMainControlador(getActivity(), handler);
        initView(view);
        controller.iniciarDatos();

        return view;
    }

    @SuppressWarnings("deprecation")
    private void initView(View view) {
        log.v(this, "initView()");

        this.layoutBlack = (LinearLayout) view.findViewById(R.id.blackLayout);
        this.layoutBlack.setOnTouchListener(this);
        this.layoutCenter = (LinearLayout) view.findViewById(R.id.linearLayoutCenter);

        //Widgets
        this.vistaSuperficie = (SurfaceView) view.findViewById(R.id.svPreview);
        this.vistaSuperficie.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_LOW);
        this.vistaSuperficie.setDrawingCacheEnabled(true);
        this.vistaSuperficie.setZOrderOnTop(true);
        this.vistaSuperficie.setOnTouchListener(this);
        this.shPreview = this.vistaSuperficie.getHolder();
        this.shPreview.addCallback(this);
        this.shPreview.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        this.shPreview.setFormat(PixelFormat.TRANSPARENT);

        this.btnAuto = (Button) view.findViewById(R.id.btnAuto);
        this.btnAuto.setOnClickListener(this);
        this.btnBlack = (Button) view.findViewById(R.id.btnBlack);
        this.btnBlack.setOnClickListener(this);
        this.btnCapture = (Button) view.findViewById(R.id.btnCapture);
        this.btnCapture.setOnClickListener(this);
        this.btnFace = (Button) view.findViewById(R.id.btnFace);
        this.btnFace.setOnClickListener(this);
        this.btnVideo = (Button) view.findViewById(R.id.btnVideo);
        this.btnVideo.setOnClickListener(this);
        this.btnSwitchCam = (Button) view.findViewById(R.id.btnSwitchCam);
        this.btnSwitchCam.setOnClickListener(this);
        this.btnDecSize = (Button) view.findViewById(R.id.btnDecreaseSize);
        this.btnDecSize.setOnClickListener(this);
        this.btnIncSize = (Button) view.findViewById(R.id.btnIncreaseSize);
        this.btnIncSize.setOnClickListener(this);
        this.btnHelp = (Button) view.findViewById(R.id.btnHelp);
        this.btnHelp.setOnClickListener(this);
        this.btnSetting = (Button) view.findViewById(R.id.btnSetting);
        this.btnSetting.setOnClickListener(this);

        sgdPreview = new ScaleGestureDetector(activity, this);
        sgdBlack = new ScaleGestureDetector(activity, this);

        layoutBlack.setVisibility(View.INVISIBLE);
        layoutBlack.setOnTouchListener(this);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
            btnFace.setVisibility(View.INVISIBLE);
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.GINGERBREAD) {
            btnVideo.setVisibility(View.INVISIBLE);
        }

    }

    @Override
    public void onClick(View v) {
        log.v(this, "onClick()");
        if (v == btnCapture) {
            controller.capturaImagen();
        } else if (v == btnAuto) {
            controller.CapturaautomticaImagen();
        } else if (v == btnSetting) {
            controller.abrirAjustes();
        } else if (v == btnFace) {
            controller.autoCapuraCara();
        } else if (v == btnVideo) {
            controller.grabandoVideo();
        } else if (v == btnIncSize) {
            controller.iniciarTamanioPrevio(layoutCenter.getWidth());
        } else if (v == btnDecSize) {
            controller.detectarTamanio();
        } else if (v == btnBlack) {
            controller.cambiarAPantallaNegra();
        } else if (v == btnSwitchCam) {
            controller.cambiarCamara();
        } else if (v == btnHelp) {
            mostrarAyuda();
        }
    }

    private void mostrarAyuda() {
        AlertDialog dialog = new AlertDialog.Builder(activity).create();
        dialog.setTitle(this.getString(R.string.help));

        WebView vistaWeb = new WebView(activity);
        vistaWeb.loadData(this.getString(R.string.help_html), "texto/html", "utf-8");
        vistaWeb.setScrollContainer(true);
        dialog.setView(vistaWeb);

        dialog.setButton(AlertDialog.BUTTON_NEGATIVE, this.getString(android.R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        dialog.setButton(AlertDialog.BUTTON_POSITIVE, "calificalo", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Uri uri = Uri.parse("mercado://details?id=" + activity.getPackageName());
                Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
                try {
                    activity.startActivity(myAppLinkToMarket);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(activity, "Fallo en encontar aolicacion", Toast.LENGTH_LONG).show();
                }
            }
        });
        dialog.setButton(AlertDialog.BUTTON_NEUTRAL, "COmpartir", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Utilidades.Compartir(activity);
            }
        });
        dialog.show();
    }

    @Override
    public boolean onTouch(View vista, MotionEvent evento) {
        log.v(this, "enToque(accion:" + evento.getAction() + "|accionindex:" + evento.getActionIndex() + "|bajotiempo:" + evento.getDownTime() + "|tiempoevento:" + evento.getEventTime() + ")");
        if (vista == layoutBlack) {
            sgdBlack.onTouchEvent(evento);
            if (evento.getAction() == MotionEvent.ACTION_DOWN) {
                controller.pantallaNegraClic();
            }
            return true;
        } else if (vista == vistaSuperficie) {
            sgdPreview.onTouchEvent(evento);
            return true;
        }
        return false;
    }

    public SurfaceView getVistaSuperficie() {
        return vistaSuperficie;
    }

    @Override
    public void onResume() {
        log.v(this, "enResumen()");
        super.onResume();
        controller.uiResumen(vistaSuperficie);
    }

    @Override
    public void onPause() {
        log.v(this, "enPausa()");
        super.onPause();
        controller.uiPausa();
    }

    @Override
    public void surfaceChanged(SurfaceHolder controlador, int format, int width,
                               int height) {
        log.v(this, "uperficieCmabiada(format:" + format + ",width:" + width + ",height:" + height + ")");
        controller.configurarCamara(controlador);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        log.v(this, "surfaceCreated()");
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        log.v(this, "surfaceDestroyed()");
    }

    @Override
    public boolean onScale(ScaleGestureDetector sgd) {
        if (sgd == sgdPreview) {
            return controller.VistaEnEscala(sgd);
        } else if (sgd == sgdBlack) {
            return controller.enPantallaNegra(sgd);
        }
        return false;
    }

    @Override
    public boolean onScaleBegin(ScaleGestureDetector sgd) {
        log.v(this, "onScaleBegin()");
        return true;
    }

    @Override
    public void onScaleEnd(ScaleGestureDetector sgd) {
        log.v(this, "onScaleEnd()");
    }


    public Button getBtnAuto() {
        return btnAuto;
    }

    public Button getBtnCapture() {
        return btnCapture;
    }

    public Button getBtnSetting() {
        return btnSetting;
    }

    public Button getBtnFace() {
        return btnFace;
    }

    public Button getBtnIncSize() {
        return btnIncSize;
    }

    public Button getBtnDecSize() {
        return btnDecSize;
    }

    public Button getBtnBlack() {
        return btnBlack;
    }

    public Button getBtnSwitchCam() {
        return btnSwitchCam;
    }

    public Button getBtnVideo() {
        return btnVideo;
    }

    public Button getBtnHelp() {
        return btnHelp;
    }

    public SurfaceHolder getShPreview() {
        return shPreview;
    }

    public LinearLayout getLayoutBlack() {
        return layoutBlack;
    }

    public Main_Controlador getController() {
        return controller;
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        log.v(this, "onKeyDown(keycode:" + keyCode + ")");
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            return controller.presionarAtras();
        } else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            return controller.PresionarBajarVolumen();

        } else if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            return controller.PresionarSubirVolumen();
			//TODO

        } else if (keyCode == KeyEvent.KEYCODE_MENU) {
            return controller.presionarMenu();
        }
        return false;
    }

    public void setVisible() {
        log.v(this, "setVisible()");
        ((RelativeLayout) view.findViewById(R.id.wholeLayout)).setVisibility(View.VISIBLE);
    }

    public void callWidgetAction(int action) {
        log.v(this, "LlamarFuncionAjuste(" + action + ")");
        controller.LlamarFuncionAjuste(action);
    }

    public void setVisibleForWidget() {
        log.v(this, "setVisibleParaAjustet()");
        ((RelativeLayout) view.findViewById(R.id.wholeLayout)).setVisibility(View.VISIBLE);
        ((LinearLayout) view.findViewById(R.id.linearLayoutLeft)).setVisibility(View.INVISIBLE);
        ((LinearLayout) view.findViewById(R.id.linearLayoutRight)).setVisibility(View.INVISIBLE);
        ((LinearLayout) view.findViewById(R.id.linearLayoutCenterButton)).setVisibility(View.INVISIBLE);
        ((Button) view.findViewById(R.id.btnDecreaseSize)).setVisibility(View.INVISIBLE);
        ((Button) view.findViewById(R.id.btnIncreaseSize)).setVisibility(View.INVISIBLE);
        SurfaceView svPreview = ((SurfaceView) view.findViewById(R.id.svPreview));
        ViewGroup.LayoutParams params = svPreview.getLayoutParams();
        params.height = 1;
        params.width = 1;
        svPreview.setLayoutParams(params);
    }

}
