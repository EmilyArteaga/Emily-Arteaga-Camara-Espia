
package com.jwork.arteaga;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.jwork.arteaga.Capa_Negocio.Llamado_Camara;
import com.jwork.arteaga.Capa_Datos.UtilidadInicio;

public class Notificaciones extends Activity {

    private UtilidadInicio log;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        log = UtilidadInicio.getInstancia();
        log.v(this, "onCreate");
        setContentView(R.layout.activity_notification);
        Intent intent = new Intent(this, Llamado_Camara.class);
        stopService(intent);
        finish();
    }

}